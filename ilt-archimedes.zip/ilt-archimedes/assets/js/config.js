/* Pengaturan umum ILT Hukum Archimedes (versi siswa, hasil diunduh sebagai file). */
window.ILT_CONFIG = {
  maxAttempts: 2,        // percobaan sebelum kunci ditampilkan
  timeLimitMinutes: 25,  // 0 = tanpa batas waktu
  storageKey: "ilt-archimedes-v1",
  minReflectionChars: 8  // panjang minimal jawaban refleksi
};
