/* =====================================================================
   content.js  -  seluruh isi tugas ILT Hukum Archimedes
   Sumber: file "Skema Interactive Learning Task Archimedes.xlsx"
   Ubah hanya teks di dalam tanda kutip. {Y} diisi otomatis (nama gelas).
   Bagian bertanda DRAF = belum tertulis lengkap di skema, perlu dicek.
   ===================================================================== */
(function () {
  "use strict";

  var GLASS = { alk: "alkohol", air: "air putih", sir: "sirup" };
  var GL = ["alk", "air", "sir"];
  var ARAH = [
    { id: "besar", text: "lebih besar" },
    { id: "kecil", text: "lebih kecil" }
  ];
  var REL = [
    { id: "kecil", text: "lebih kecil dari" },
    { id: "sama", text: "sama besar dengan" },
    { id: "besar", text: "lebih besar dari" }
  ];
  function lowerFirst(s) { return s.charAt(0).toLowerCase() + s.slice(1); }
  function upperFirst(s) { return s.charAt(0).toUpperCase() + s.slice(1); }
  function opt(id, text, glass) { var o = { id: id, text: text }; if (glass) o.glass = glass; return o; }

  /* ---------------------------------------------------------------
     TABEL 1  -  Deskripsi skema  (1 x 3 x 3 = 9 kalimat, 3 benar)
     --------------------------------------------------------------- */
  var t1Sentences = [];
  var t1Right = { alk: "teng", air: "apung", sir: "apung" };
  ["teng", "apung", "layang"].forEach(function (r) {
    GL.forEach(function (g) {
      var s = { key: ["es", r, g].join("|"), y: GLASS[g] };
      if (t1Right[g] === r) {
        s.ok = true;
        s.core = GL.indexOf(g) + 1;                 // inti 1 = alkohol, 2 = air putih, 3 = sirup
      } else {
        s.ok = false;
        s.err = r === "apung" ? "K1" : r === "teng" ? "K2" : "K3";
        s.fix = ["es", t1Right[g], g].join("|");
      }
      t1Sentences.push(s);
    });
  });

  var tabel1 = {
    id: "t1",
    nama: "Tabel 1",
    judul: "Tabel 1. Deskripsi skema",
    petunjuk: "Susun kalimat yang menggambarkan keadaan es batu di setiap gelas. Ketuk satu kotak di setiap kolom, lalu tekan + Tambahkan kalimat.",
    catatan: "Ada 9 kemungkinan kalimat. Susun kalimat yang menurutmu benar, tidak perlu semuanya.",
    columns: [
      { label: "Benda", options: [opt("es", "Es batu")] },
      { label: "Keadaan", options: [opt("teng", "tenggelam"), opt("apung", "mengapung"), opt("layang", "melayang")] },
      { label: "Gelas", options: [opt("alk", "di alkohol", "alk"), opt("air", "di air putih", "air"), opt("sir", "di sirup", "sir")] }
    ],
    sentences: t1Sentences,
    errors: {
      K1: {
        nama: "“Mengapung” untuk gelas alkohol",
        a1: "✗ Lihat posisi es batu di gelas alkohol pada gambar. Apakah es batu itu sampai ke permukaan cairan?",
        a2: "✗ Es batu di gelas alkohol berada di dasar gelas. Bandingkan dengan posisi es batu di gelas lain."
      },
      K2: {
        nama: "“Tenggelam” untuk gelas air putih atau sirup",
        a1: "✗ Lihat posisi es batu di gelas {Y} pada gambar. Apakah es batu itu berada di dasar gelas?",
        a2: "✗ Es batu di gelas {Y} tampak di permukaan cairan, ada bagian yang muncul di atas. Bandingkan dengan es batu di gelas alkohol."
      },
      K3: {
        nama: "“Melayang” untuk gelas mana pun",
        a1: "✗ Melayang berarti seluruh es batu tercelup dan tidak menyentuh dasar maupun permukaan. Lihat posisi es batu di gelas {Y}: apakah sesuai?",
        a2: "✗ Es batu di gelas {Y} tidak melayang. Ada dua kemungkinan lain, yaitu menyentuh dasar atau sebagian muncul di permukaan. Pilih yang sesuai gambar."
      }
    },
    groups: {
      1: {
        nama: "Gelas alkohol",
        a1: "✓ Kalimatmu tepat. Susun juga kalimat tentang es batu di gelas alkohol.",
        a2: "✓ Kalimatmu tepat. Lihat posisi es batu di gelas alkohol pada gambar, lalu susun kalimatnya."
      },
      2: {
        nama: "Gelas air putih",
        a1: "✓ Kalimatmu tepat. Susun juga kalimat tentang es batu di gelas air putih.",
        a2: "✓ Kalimatmu tepat. Lihat posisi es batu di gelas air putih pada gambar, lalu susun kalimatnya."
      },
      3: {
        nama: "Gelas sirup",
        a1: "✓ Kalimatmu tepat. Susun juga kalimat tentang es batu di gelas sirup kental.",
        a2: "✓ Kalimatmu tepat. Lihat posisi es batu di gelas sirup kental pada gambar, lalu susun kalimatnya."
      }
    },
    complete: "✓ Semua kalimatmu tepat dan sudah lengkap. Ingat lagi cara yang kamu pakai tadi untuk membaca posisi es batu pada gambar. Cara itu akan berguna lagi di Tabel 2.",
    keyFooter: "Cocokkan dengan kalimatmu tadi. Ingat lagi posisi es batu di setiap gelas pada gambar, lalu perhatikan bagian yang tadi terlewat."
  };

  /* ---------------------------------------------------------------
     TABEL 2  -  Membandingkan parameter (36 kalimat, 12 benar, 6 hal inti)
     Kotak 1 | relasi | Kotak 3, hanya pasangan sejenis yang diizinkan.
     --------------------------------------------------------------- */
  var t2Sentences = [];
  function add2(c0, rel, c2, truth, core, err, g) {
    var ok = rel === truth;
    var s = { key: [c0, rel, c2].join("|"), ok: ok, y: GLASS[g] };
    if (ok) { if (core) s.core = core; }
    else { s.err = err; s.fix = [c0, truth, c2].join("|"); }
    t2Sentences.push(s);
  }
  GL.forEach(function (g) {
    REL.forEach(function (r) {
      // A. massa jenis es batu dengan massa jenis cairan
      add2("rho", r.id, "rho_" + g, g === "alk" ? "besar" : "kecil", g === "alk" ? 1 : 2, "M1", g);
    });
    REL.forEach(function (r) {
      // B. gaya apung di gelas dengan berat es batu
      add2("f_" + g, r.id, "w_es", g === "alk" ? "kecil" : "sama", g === "alk" ? 3 : 4, g === "alk" ? "M2" : "M3", g);
    });
    REL.forEach(function (r) {
      // C. gaya apung dengan berat cairan yang tumpah dari gelas yang sama
      add2("f_" + g, r.id, "w_" + g, "sama", 5, "M4", g);
    });
    REL.forEach(function (r) {
      // D. volume es yang tercelup dengan volume es batu seluruhnya
      add2("v_" + g, r.id, "v_es", g === "alk" ? "sama" : "kecil", g === "alk" ? 0 : 6, "M5", g);
    });
  });

  var tabel2 = {
    id: "t2",
    nama: "Tabel 2",
    judul: "Tabel 2. Membandingkan parameter",
    petunjuk: "Bandingkan besaran-besaran pada es batu dan cairan di setiap gelas. Pilih besaran di kotak kiri, hubungannya, lalu besaran di kotak kanan.",
    catatan: "Kotak yang dicoret tidak bisa dipasangkan dengan pilihanmu. Ada 36 kemungkinan kalimat; susun yang menurutmu benar dan penting.",
    columns: [
      {
        label: "Besaran 1",
        options: [
          opt("rho", "Massa jenis es batu"),
          opt("f_alk", "Gaya apung di gelas alkohol", "alk"),
          opt("f_air", "Gaya apung di gelas air putih", "air"),
          opt("f_sir", "Gaya apung di gelas sirup", "sir"),
          opt("v_alk", "Volume es yang tercelup di gelas alkohol", "alk"),
          opt("v_air", "Volume es yang tercelup di gelas air putih", "air"),
          opt("v_sir", "Volume es yang tercelup di gelas sirup", "sir")
        ]
      },
      { label: "Hubungan", options: REL.map(function (r) { return opt(r.id, r.text); }) },
      {
        label: "Besaran 2",
        options: [
          opt("rho_alk", "Massa jenis alkohol", "alk"),
          opt("rho_air", "Massa jenis air putih", "air"),
          opt("rho_sir", "Massa jenis sirup", "sir"),
          opt("w_es", "Berat es batu"),
          opt("w_alk", "Berat cairan yang tumpah dari gelas alkohol", "alk"),
          opt("w_air", "Berat cairan yang tumpah dari gelas air putih", "air"),
          opt("w_sir", "Berat cairan yang tumpah dari gelas sirup", "sir"),
          opt("v_es", "Volume es batu seluruhnya")
        ]
      }
    ],
    sentences: t2Sentences,
    errors: {
      M1: {
        nama: "Massa jenis salah urutan",
        a1: "✗ Baca angka massa jenis pada gambar. Bandingkan angka es batu dengan angka cairan {Y}.",
        a2: "✗ Angka yang lebih besar berarti massa jenis yang lebih besar. Periksa lagi urutan es batu dan cairan {Y}."
      },
      M2: {
        nama: "Gaya apung di gelas alkohol sama atau lebih besar dari berat es",
        a1: "✗ Ingat hasil Tabel 1: bagaimana kondisi es di gelas alkohol? Kalau gaya apung sama besar dengan berat es, es akan berada di posisi bagaimana?",
        a2: "✗ Es batu yang mengapung atau melayang diam karena gaya apung sama besar dengan beratnya. Es di gelas alkohol tidak begitu (Tabel 1). Periksa lagi kalimatmu."
      },
      M3: {
        nama: "Gaya apung di gelas yang es-nya mengapung tidak sama dengan berat es",
        a1: "✗ Ingat hasil Tabel 1: es di gelas {Y} mengapung dan diam. Gaya-gaya pada es batu itu seimbang atau tidak?",
        a2: "✗ Es yang diam mengapung berarti gaya ke atas dan gaya ke bawah pada es sama besar. Gaya ke atas itu gaya apung, dan gaya ke bawah itu berat es. Periksa lagi kalimatmu."
      },
      M4: {
        nama: "Gaya apung dengan berat cairan tumpah salah",
        a1: "✗ Ingat percobaan gelas berpancuran di Fase 3. Bandingkan gaya apung dengan berat air yang tumpah. Apa hubungannya?",
        a2: "✗ Pikirkan hubungan gaya apung dan berat air yang tumpah pada percobaan Fase 3. Terapkan hubungan itu pada gelas {Y}."
      },
      M5: {
        nama: "Volume tercelup salah",
        a1: "✗ Ingat hasil Tabel 1 dan lihat gambar. Apakah seluruh es batu di gelas {Y} berada di dalam cairan?",
        a2: "✗ Lihat lagi es batu di gelas {Y} pada gambar. Seluruh es berada di dalam cairan, atau ada bagian yang muncul di permukaan? Bandingkan dengan volume es seluruhnya."
      }
    },
    groups: {
      1: {
        nama: "Massa jenis es dan alkohol",
        a1: "✓ Kalimatmu tepat. Bandingkan massa jenis es batu dengan massa jenis alkohol.",
        a2: "✓ Kalimatmu tepat. Baca angka massa jenis es batu dan alkohol pada gambar, lalu bandingkan."
      },
      2: {
        nama: "Massa jenis es dan cairan lain",
        a1: "✓ Kalimatmu tepat. Bandingkan massa jenis es batu dengan massa jenis cairan di gelas yang es-nya mengapung.",
        a2: "✓ Kalimatmu tepat. Baca angka massa jenis es batu dan cairan di gelas yang es-nya mengapung, lalu bandingkan."
      },
      3: {
        nama: "Gaya apung di gelas alkohol",
        a1: "✓ Kalimatmu tepat. Bandingkan gaya apung di gelas alkohol dengan berat es.",
        a2: "✓ Kalimatmu tepat. Ingat hasil Tabel 1: es di gelas alkohol tenggelam. Pakai itu untuk membandingkan gaya apung dengan berat es."
      },
      4: {
        nama: "Gaya apung di gelas yang es-nya mengapung",
        a1: "✓ Kalimatmu tepat. Bandingkan gaya apung dengan berat es di gelas yang es-nya mengapung.",
        a2: "✓ Kalimatmu tepat. Ingat hasil Tabel 1: es di air putih dan sirup mengapung. Pakai itu untuk membandingkan gaya apung dengan berat es."
      },
      5: {
        nama: "Gaya apung dan cairan tumpah",
        a1: "✓ Kalimatmu tepat. Bandingkan gaya apung dengan berat cairan yang tumpah.",
        a2: "✓ Kalimatmu tepat. Ingat percobaan gelas berpancuran di Fase 3. Pakai hasilnya untuk membandingkan gaya apung dengan berat cairan yang tumpah di salah satu gelas."
      },
      6: {
        nama: "Volume tercelup",
        a1: "✓ Kalimatmu tepat. Bandingkan volume es yang tercelup dengan volume es seluruhnya di gelas yang es-nya mengapung.",
        a2: "✓ Kalimatmu tepat. Lihat gambar: bagian es yang tercelup di gelas air putih dan sirup. Bandingkan dengan volume es seluruhnya."
      }
    },
    complete: "✓ Semua kalimatmu tepat dan sudah lengkap. Ingat lagi cara yang kamu pakai tadi untuk membandingkan gaya, massa jenis, dan volume pada es batu. Cara itu akan berguna lagi di Tabel 3.",
    keyFooter: "Cocokkan dengan kalimatmu tadi. Ingat lagi hasil Tabel 1 dan data pada gambar, lalu perhatikan bagian yang tadi terlewat."
  };

  /* ---------------------------------------------------------------
     TABEL 3  -  Hubungan antarparameter (3 syarat x 2 arah x 2 arah = 12 kalimat, 6 benar)
     Besaran di kotak 2 dan 4 terisi otomatis menurut syarat.
     --------------------------------------------------------------- */
  var T3Q = {
    rho: ["volume tercelup", "gaya apung"],
    v: ["massa jenis cairan", "gaya apung"],
    f: ["massa jenis cairan", "volume tercelup"]
  };
  var T3COND = {
    rho: "massa jenis cairan yang sama",
    v: "volume tercelup yang sama",
    f: "gaya apung yang sama"
  };
  var t3Sentences = [];
  ["rho", "v", "f"].forEach(function (c, ci) {
    ["besar", "kecil"].forEach(function (a1) {
      ["besar", "kecil"].forEach(function (a2) {
        var ok = c === "f" ? a1 !== a2 : a1 === a2;
        var s = { key: [c, a1, a2].join("|"), ok: ok };
        if (ok) s.core = ci + 1;
        else {
          s.err = "N" + (ci + 1);
          s.fix = [c, a1, c === "f" ? (a1 === "besar" ? "kecil" : "besar") : a1].join("|");
        }
        t3Sentences.push(s);
      });
    });
  });
  function arahText(id) { return id === "besar" ? "lebih besar" : "lebih kecil"; }

  var tabel3 = {
    id: "t3",
    nama: "Tabel 3",
    judul: "Tabel 3. Hubungan antarparameter",
    petunjuk: "Pilih syarat lebih dulu. Dua besaran akan terisi otomatis, lalu pilih arah (lebih besar atau lebih kecil) untuk masing-masing.",
    catatan: "Cukup susun satu kalimat benar untuk tiap syarat.",
    columns: [
      { label: "Syarat", options: [opt("rho", "Massa jenis cairan yang sama"), opt("v", "Volume tercelup yang sama"), opt("f", "Gaya apung yang sama")] },
      { label: "Besaran 1", options: ARAH.map(function (a) { return opt(a.id, a.text); }) },
      { label: "Besaran 2", options: ARAH.map(function (a) { return opt(a.id, a.text); }) }
    ],
    connectors: ["Pada", "", "berarti"],
    colLabel: function (i, sel) {
      if (i === 1 && sel[0]) return upperFirst(T3Q[sel[0]][0]);
      if (i === 2 && sel[0]) return upperFirst(T3Q[sel[0]][1]);
      return this.columns[i].label;
    },
    slot: function (i, id, sel) {
      if (i === 0) return T3COND[id];
      var q = sel[0] ? T3Q[sel[0]][i - 1] : (i === 1 ? "besaran 1" : "besaran 2");
      return q + " " + arahText(id);
    },
    sentence: function (ids) {
      var q = T3Q[ids[0]];
      return "Pada " + T3COND[ids[0]] + ", " + q[0] + " " + arahText(ids[1]) + " berarti " + q[1] + " " + arahText(ids[2]);
    },
    sentences: t3Sentences,
    errors: {
      N1: {
        nama: "Arah salah pada “massa jenis cairan yang sama”",
        a1: "✗ Ingat Percobaan A di Fase 3: beban dengan volume lebih besar dicelupkan ke air yang sama. Gaya apungnya bagaimana?",
        a2: "✗ Lihat lagi data Tabel Percobaan A1 di Fase 3. Bandingkan volume beban yang tercelup dengan gaya apungnya, lalu sesuaikan kalimatmu dengan temuan itu."
      },
      N2: {
        nama: "Arah salah pada “volume tercelup yang sama”",
        a1: "✗ Gaya apung sama dengan berat cairan yang dipindahkan. Kalau volume cairan yang dipindahkan sama, cairan yang massa jenisnya lebih besar menghasilkan berat yang lebih besar atau lebih kecil?",
        a2: "✗ Volume cairan yang dipindahkan sama besar, jadi berat cairan itu ditentukan oleh massa jenisnya. Sesuaikan kalimatmu dengan hubungan itu."
      },
      N3: {
        nama: "Arah salah pada “gaya apung yang sama”",
        a1: "✗ Lihat Tabel 2: gaya apung di gelas air putih dan sirup sama besar. Bandingkan massa jenis kedua cairan dan bagian es yang tercelup di keduanya.",
        a2: "✗ Es di gelas air putih dan sirup sama-sama mengapung dengan gaya apung yang sama. Di gelas mana es lebih banyak tercelup, dan cairan mana yang massa jenisnya lebih besar? Sesuaikan kalimatmu."
      }
    },
    groups: {
      1: {
        nama: "Volume tercelup dan gaya apung",
        a1: "✓ Kalimatmu tepat. Masih ada hubungan antara volume tercelup dan gaya apung yang belum kamu sebut.",
        a2: "✓ Kalimatmu tepat. Ingat Percobaan A di Fase 3: pada air yang sama, bagaimana hubungan volume beban yang tercelup dengan gaya apung?"
      },
      2: {
        nama: "Massa jenis cairan dan gaya apung",
        a1: "✓ Kalimatmu tepat. Masih ada hubungan antara massa jenis cairan dan gaya apung yang belum kamu sebut.",
        a2: "✓ Kalimatmu tepat. Gaya apung sama dengan berat cairan yang dipindahkan. Kalau volume yang dipindahkan sama, bagaimana hubungan massa jenis cairan dan gaya apungnya?"
      },
      3: {
        nama: "Massa jenis cairan dan volume tercelup",
        a1: "✓ Kalimatmu tepat. Masih ada hubungan antara massa jenis cairan dan volume tercelup yang belum kamu sebut.",
        a2: "✓ Kalimatmu tepat. Pikirkan es di gelas air putih dan sirup yang gaya apungnya sama. Bagaimana hubungan massa jenis cairan dan volume es yang tercelup?"
      }
    },
    complete: "✓ Semua kalimatmu tepat dan sudah lengkap. Lanjut ke Kesimpulan.",
    keyFooter: "Cocokkan dengan kalimatmu tadi. Ingat lagi hasil Tabel 1 dan 2, lalu perhatikan bagian yang tadi terlewat."
  };

  /* ---------------------------------------------------------------
     KESIMPULAN  -  satu pilihan (kunci: d)
     --------------------------------------------------------------- */
  var kesimpulan = {
    id: "ks",
    nama: "Kesimpulan",
    judul: "Kesimpulan",
    petunjuk: "Pilih satu alasan yang paling tepat, lalu pilih tingkat keyakinanmu.",
    soal: "Es batu tenggelam di alkohol, tetapi mengapung di air putih dan sirup. Bagian es yang muncul di permukaan lebih banyak di sirup daripada di air putih. Hal ini terjadi karena…",
    key: "d",
    options: [
      { id: "a", text: "Massa jenis es lebih kecil daripada massa jenis alkohol, air putih, dan sirup, dan cairan bermassa jenis lebih besar membuat bagian es yang tercelup lebih sedikit.", err: "KS-a" },
      { id: "b", text: "Massa jenis es lebih besar daripada massa jenis alkohol dan lebih kecil daripada massa jenis air putih dan sirup, dan cairan bermassa jenis lebih besar membuat bagian es yang tercelup lebih banyak.", err: "KS-b" },
      { id: "c", text: "Gaya apung ditentukan oleh volume cairan yang tumpah saja, sehingga di alkohol yang tumpahannya paling banyak gaya apungnya paling besar.", err: "KS-c" },
      { id: "d", text: "Massa jenis es lebih besar daripada massa jenis alkohol dan lebih kecil daripada massa jenis air putih dan sirup, dan cairan bermassa jenis lebih besar membuat bagian es yang tercelup lebih sedikit." }
    ],
    messages: {
      a: {
        a1: "✗ Bagian tentang bagian es yang tercelup sudah tepat. Periksa bagian massa jenis es. Bandingkan angka es batu dengan angka alkohol pada gambar, lalu ingat hasil Tabel 1.",
        a2: "✗ Bagian tentang bagian es yang tercelup sudah tepat. Es batu tenggelam di alkohol (Tabel 1). Es hanya tenggelam kalau massa jenisnya lebih besar daripada massa jenis cairannya. Bandingkan lagi massa jenis es dengan alkohol."
      },
      b: {
        a1: "✗ Bagian tentang massa jenis es sudah tepat. Periksa bagian es yang tercelup. Lihat kembali Tabel 3 tentang gaya apung yang sama.",
        a2: "✗ Bagian tentang massa jenis es sudah tepat. Es di air putih dan sirup mengapung dengan gaya apung yang sama (Tabel 2). Pada gaya apung yang sama, massa jenis cairan lebih besar berarti volume tercelup lebih kecil (Tabel 3)."
      },
      c: {
        a1: "✗ Lihat kembali Tabel 3. Besaran apa saja yang menentukan gaya apung?",
        a2: "✗ Gaya apung sama dengan berat cairan yang dipindahkan, dan berat itu bergantung pada volume dan massa jenis cairan, bukan volume saja (Tabel 3). Gunakan keduanya untuk menjelaskan mengapa es tenggelam di alkohol dan mengapung di air putih dan sirup."
      },
      d: {
        a1: "✓ Tepat. Massa jenis es lebih besar daripada alkohol sehingga es tenggelam, dan lebih kecil daripada air putih dan sirup sehingga es mengapung. Makin besar massa jenis cairan, makin sedikit bagian es yang perlu tercelup agar gaya apung sama dengan berat es.",
        a2: null  // null = sama dengan percobaan ke-1
      }
    }
  };

  /* ---------------------------------------------------------------
     PELUANG  -  P.1 (jawaban) dan P.2 (alasan)
     Catatan skema: sheet menulis "Kunci: c" untuk P.1, tetapi baris umpan balik
     menyebut P.1 b = 3/8, c = 1/2, d = pasti, dan "P.1 a" sebagai jawaban tepat.
     Maka P.1 a (5/8) dipakai sebagai kunci. DRAF: teks pilihan P.2 a-d disusun
     dari umpan balik di skema.
     --------------------------------------------------------------- */
  var peluang = {
    id: "pl",
    nama: "Peluang",
    judul: "Peluang",
    petunjuk: "Jawab P.1 dan P.2, lalu pilih tingkat keyakinanmu. Keduanya harus dipilih sebelum Periksa.",
    soal: "Sebuah kotak berisi 8 benda. Satu benda diambil secara acak, lalu dimasukkan ke bak berisi air putih (massa jenis 1.000 kg/m³).",
    tanya: "Berapa peluang benda itu mengapung?",
    benda: [
      ["gabus", 250], ["kayu", 600], ["apel", 800], ["lilin", 900],
      ["plastik", 950], ["batu", 2500], ["aluminium", 2700], ["besi", 7800]
    ],
    airMassaJenis: 1000,
    p1: {
      key: "a",
      options: [
        { id: "a", text: "5/8" },
        { id: "b", text: "3/8" },
        { id: "c", text: "1/2" },
        { id: "d", text: "Pasti mengapung" }
      ],
      messages: {
        b: {
          a1: "✗ Perhatikan yang ditanyakan: peluang benda mengapung. Hitung benda yang massa jenisnya lebih kecil daripada massa jenis air putih.",
          a2: "✗ Benda yang massa jenisnya lebih kecil daripada air putih mengapung. Ada 5 benda seperti itu dari 8 benda. Tiga benda sisanya tenggelam."
        },
        c: {
          a1: "✗ Gunakan banyaknya benda yang mengapung, bukan banyaknya kemungkinan.",
          a2: "✗ Hasilnya bukan dua kemungkinan yang sama peluangnya. Peluang = banyak benda yang mengapung : seluruh benda."
        },
        d: {
          a1: "✗ Hitung berapa benda yang mengapung dari seluruh benda.",
          a2: "✗ Ada benda yang massa jenisnya lebih besar daripada air putih (batu, aluminium, dan besi), jadi tidak pasti benda yang diambil mengapung."
        }
      }
    },
    p2: {
      key: "a",
      options: [
        { id: "a", text: "Ada 5 dari 8 benda yang massa jenisnya lebih kecil daripada massa jenis air putih, sehingga benda itu mengapung." },
        { id: "b", text: "Hanya ada dua kemungkinan, benda mengapung atau tenggelam, sehingga peluangnya sama besar.", err: "P2-bc" },
        { id: "c", text: "Setiap benda punya peluang yang sama untuk diambil, sehingga peluang mengapung sama dengan peluang tenggelam.", err: "P2-bc" },
        { id: "d", text: "Benda diambil secara acak, sehingga tidak mungkin diperkirakan benda itu mengapung atau tenggelam.", err: "P2-d" }
      ],
      // pesan untuk alasan yang belum tepat
      messages: {
        bc: {
          a1: "✗ Alasannya belum tepat. Alasan yang tepat memakai data yang diberikan.",
          a2: "✗ Alasannya belum tepat. Pilih alasan yang menyebut berapa benda yang massa jenisnya lebih kecil daripada massa jenis air putih."
        },
        d: {
          a1: "✗ Alasannya belum tepat. Alasan itu tidak memakai data pada soal.",
          a2: "✗ Alasannya belum tepat. Pilih alasan yang menyebut berapa benda yang massa jenisnya lebih kecil daripada massa jenis air putih."
        }
      }
    },
    p1BenarTeks: "✓ Jawabanmu tepat. ",
    p2BenarTeks: "Alasanmu sudah tepat. Gunakan alasan itu untuk menghitung jawabanmu.",
    complete: "✓ Tepat. 5 dari 8 benda memiliki massa jenis lebih kecil daripada massa jenis air putih, jadi peluangnya 5/8."
  };

  /* ---------------------------------------------------------------
     TEKS UMUM
     --------------------------------------------------------------- */
  window.ILT_CONTENT = {
    judul: "ILT Hukum Archimedes",
    gambar: "assets/img/gelas.jpg",
    glass: GLASS,
    soalUtama: "Perhatikan gambar tiga gelas di samping! Gelas-gelas itu berisi alkohol, air putih, dan sirup sampai penuh. Satu es batu yang sama dimasukkan perlahan ke dalam tiap gelas, dan sebagian cairan tumpah. Bagaimana es batu dan cairan di setiap gelas berhubungan satu sama lain? Berikan alasan jawabanmu dengan menyusun kalimat pada Tabel 1, 2, dan 3.",
    caraMengerjakan: [
      "Susun kalimat dengan mengetuk satu kotak di setiap kolom. Di laptop, kotak juga bisa diseret ke baris kalimat.",
      "Tekan + Tambahkan kalimat. Kalimat masuk ke daftar jawabanmu.",
      "Pilih tingkat keyakinanmu (1–4), lalu tekan Periksa.",
      "Baca umpan balik, perbaiki kalimatmu, lalu Periksa lagi."
    ],
    bagian: [
      { id: "t1", nama: "Tabel 1", ket: "Deskripsi skema", menit: 5 },
      { id: "t2", nama: "Tabel 2", ket: "Membandingkan parameter", menit: 6 },
      { id: "t3", nama: "Tabel 3", ket: "Hubungan antarparameter", menit: 4 },
      { id: "ks", nama: "Kesimpulan", ket: "Memilih alasan", menit: 2 },
      { id: "pl", nama: "Peluang", ket: "P.1 dan P.2", menit: 3 }
    ],
    keyakinan: ["Menebak", "Kurang yakin", "Yakin", "Sangat yakin"],
    refleksi: [
      "Apa yang kamu ubah dari jawabanmu setelah membaca umpan balik? Mengapa?",
      "Langkah apa yang paling membantumu menemukan jawaban yang tepat?"
    ],
    tables: { t1: tabel1, t2: tabel2, t3: tabel3 },
    ks: kesimpulan,
    pl: peluang,
    // kamus kode kesalahan untuk berkas hasil
    kodeKesalahan: (function () {
      var d = {};
      [tabel1, tabel2, tabel3].forEach(function (t) {
        Object.keys(t.errors).forEach(function (k) { d[k] = t.errors[k].nama; });
      });
      d["KS-a"] = "Salah massa jenis es";
      d["KS-b"] = "Salah bagian tercelup";
      d["KS-c"] = "Salah konsep (volume tanpa massa jenis)";
      d["P1-b"] = "Peluang 3/8";
      d["P1-c"] = "Peluang 1/2";
      d["P1-d"] = "Pasti mengapung";
      d["P2-bc"] = "Alasan tidak memakai data";
      d["P2-d"] = "Data dianggap tidak bisa dipakai";
      return d;
    })()
  };
})();
