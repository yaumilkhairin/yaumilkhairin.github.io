/* =====================================================================
   guru.js  -  dasbor guru ILT Hukum Archimedes
   Membaca berkas hasil-ILT-....json dari siswa (impor), lalu menampilkan
   ringkasan kelas, grafik, daftar siswa, rincian, dan unduhan Excel (CSV).
   Data hanya disimpan di browser guru (localStorage), tidak dikirim ke mana pun.
   ===================================================================== */
(function () {
  "use strict";

  var C = window.ILT_CONTENT;
  var KEY = "ilt-archimedes-guru-v1";
  var ORDER = ["t1", "t2", "t3", "ks", "pl"];
  var NAMA = { t1: "Tabel 1", t2: "Tabel 2", t3: "Tabel 3", ks: "Kesimpulan", pl: "Peluang" };
  var KEYAKINAN = C.keyakinan;

  /* ------------------------- util ------------------------- */
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (m) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m];
    });
  }
  function $(s, el) { return (el || document).querySelector(s); }
  function mean(a) { return a.length ? a.reduce(function (x, y) { return x + y; }, 0) / a.length : 0; }
  function f1(n) { return (Math.round(n * 10) / 10).toFixed(1).replace(".", ","); }
  function pct(n) { return Math.round(n * 100) + "%"; }
  function slug(s) { return String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 30) || "kelas"; }
  function dur(r) { return r.durasi_detik == null ? null : r.durasi_detik / 60; }
  function tgl(t) {
    if (!t) return "";
    var d = new Date(t);
    return d.toLocaleDateString("id-ID", { day: "numeric", month: "short" }) + " " +
      d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
  }

  /* ------------------------- state ------------------------- */
  var store = loadStore();
  var ui = { kelas: "", q: "", sort: "terbaru", detail: null, modal: null };

  function loadStore() {
    try {
      var s = JSON.parse(localStorage.getItem(KEY));
      if (s && Array.isArray(s.records)) return s;
    } catch (e) { /* abaikan */ }
    return { records: [], demo: false };
  }
  function saveStore() {
    try { localStorage.setItem(KEY, JSON.stringify(store)); } catch (e) { /* abaikan */ }
  }
  function rid(r) { return [r.siswa.nama, r.siswa.kelas, r.mulai].join("|"); }

  /* ------------------------- impor ------------------------- */
  function validRecord(r) {
    return r && r.siswa && r.siswa.nama && r.skor && r.skor.per_bagian && Array.isArray(r.log_percobaan);
  }
  function importFiles(files) {
    var list = Array.prototype.slice.call(files || []);
    if (!list.length) return;
    var added = 0, dup = 0, bad = 0, left = list.length;
    var incoming = [];
    list.forEach(function (f) {
      var rd = new FileReader();
      rd.onload = function () {
        try {
          var j = JSON.parse(rd.result);
          (Array.isArray(j) ? j : [j]).forEach(function (r) { if (validRecord(r)) incoming.push(r); else bad++; });
        } catch (e) { bad++; }
        if (--left === 0) done();
      };
      rd.onerror = function () { bad++; if (--left === 0) done(); };
      rd.readAsText(f);
    });
    function done() {
      if (store.demo) { store.records = []; store.demo = false; }
      var seen = {};
      store.records.forEach(function (r) { seen[rid(r)] = true; });
      incoming.forEach(function (r) {
        var k = rid(r);
        if (seen[k]) { dup++; return; }
        seen[k] = true; store.records.push(r); added++;
      });
      saveStore(); render();
      toast(added + " hasil ditambahkan" + (dup ? ", " + dup + " sudah ada" : "") + (bad ? ", " + bad + " file tidak valid" : "") + ".");
    }
  }

  /* ------------------------- data contoh ------------------------- */
  function demoRecords() {
    var seed = 20261125;
    function rnd() { seed = (seed * 1664525 + 1013904223) % 4294967296; return seed / 4294967296; }
    function pickOne(a) { return a[Math.floor(rnd() * a.length)]; }
    function sentText(T, key) {
      var ids = key.split("|");
      if (T.sentence) return T.sentence(ids);
      return ids.map(function (oid, i) {
        var o = T.columns[i].options.filter(function (x) { return x.id === oid; })[0];
        var t = o ? o.text : oid;
        return i === 0 ? t : t.charAt(0).toLowerCase() + t.slice(1);
      }).join(" ");
    }
    var names = ["Aulia Rahma", "Bagas Prakoso", "Citra Lestari", "Dimas Aditya", "Eka Putri", "Fajar Nugroho", "Gita Maharani", "Hendra Wijaya",
      "Intan Permata", "Joko Susilo", "Kirana Dewi", "Lukman Hakim", "Maya Anggraini", "Naufal Ramadhan", "Olivia Tan", "Putra Mahendra",
      "Qonita Azzahra", "Rizky Fadillah", "Salsabila Nur", "Teguh Santoso", "Umar Faruq", "Vina Oktaviani", "Wahyu Hidayat", "Yuni Kartika"];
    var pOne = { t1: .6, t2: .4, t3: .5, ks: .55, pl: .65 };
    return names.map(function (nm, idx) {
      var skill = rnd();
      var kelas = idx % 2 ? "XI IPA 2" : "XI IPA 1";
      var start = Date.UTC(2026, 10, 23, 1, 0, 0) + idx * 11 * 60000 + (idx % 2) * 86400000;
      var t = start, log = [], per = {}, bagian = {};
      ORDER.forEach(function (id) {
        var r = rnd() - (skill - .5) * .5;
        var outcome = r < pOne[id] ? 1 : (r < pOne[id] + .22 ? 2 : 3);   // 3 = kunci
        if (id === "pl" && idx === 7) outcome = 4;                         // satu siswa kehabisan waktu
        var T = C.tables[id], attempts = outcome === 1 ? 1 : outcome === 2 ? 2 : outcome === 3 ? 2 : 0;
        for (var n = 1; n <= attempts; n++) {
          t += (40 + Math.floor(rnd() * 90)) * 1000;
          var okFinal = (n === 1 && outcome === 1) || (n === 2 && outcome === 2);
          var conf = Math.min(4, Math.max(1, Math.round(1 + (okFinal ? skill : 1 - skill) * 2.5 + rnd() * 1.4)));
          if (!okFinal && n === 1 && rnd() < .28) conf = 4;
          var items, codes, status, msgs = [];
          if (T) {
            var errCodes = Object.keys(T.errors);
            if (okFinal) {
              var core = T.sentences.filter(function (s) { return s.ok && s.core; });
              items = core.slice(0, Math.min(core.length, 3)).map(function (s) { return { teks: sentText(T, s.key), benar: true, kode: null }; });
              codes = ["C"]; status = "lengkap";
            } else {
              var code = pickOne(errCodes), w = T.sentences.filter(function (s) { return s.err === code; })[0];
              var ok1 = T.sentences.filter(function (s) { return s.ok && s.core; })[0];
              items = [{ teks: sentText(T, ok1.key), benar: true, kode: null }, { teks: sentText(T, w.key), benar: false, kode: code }];
              codes = [code]; status = "salah";
              msgs = [(n === 1 ? T.errors[code].a1 : T.errors[code].a2).replace(/\{Y\}/g, w.y || "")];
            }
          } else if (id === "ks") {
            var opts = ["a", "b", "c"], ch = okFinal ? "d" : pickOne(opts), o = C.ks.options.filter(function (x) { return x.id === ch; })[0];
            items = [{ teks: o.text, benar: okFinal, kode: okFinal ? null : o.err }];
            codes = [okFinal ? "C" : o.err]; status = okFinal ? "lengkap" : "salah";
            msgs = [(n === 1 ? C.ks.messages[ch].a1 : (C.ks.messages[ch].a2 || C.ks.messages[ch].a1))];
          } else {
            var p1 = okFinal ? "a" : pickOne(["a", "b", "c", "d"]), p2 = okFinal ? "a" : pickOne(["a", "b", "c", "d"]);
            if (!okFinal && p1 === "a" && p2 === "a") p1 = "b";
            var o1 = C.pl.p1.options.filter(function (x) { return x.id === p1; })[0], o2 = C.pl.p2.options.filter(function (x) { return x.id === p2; })[0];
            items = [{ teks: "P.1 " + o1.text, benar: p1 === "a", kode: p1 === "a" ? null : "P1-" + p1 },
                     { teks: "P.2 " + o2.text, benar: p2 === "a", kode: p2 === "a" ? null : o2.err }];
            codes = okFinal ? ["C"] : items.filter(function (i) { return i.kode; }).map(function (i) { return i.kode; });
            status = okFinal ? "lengkap" : "salah";
          }
          log.push({
            layar: id, nama_layar: NAMA[id], percobaan: n, waktu: new Date(t).toISOString(), keyakinan: conf, status: status,
            status_teks: status === "lengkap" ? "Tepat & lengkap" : "Ada yang salah", kalimat: items, kode_pesan: codes, pesan: msgs,
            kunci_tampil: outcome === 3 && n === 2
          });
        }
        var skor = outcome === 1 ? 4 : outcome === 2 ? 3 : outcome === 3 ? 2 : 1;
        per[id] = skor;
        bagian[id] = {
          nama: NAMA[id], skor: skor, jumlah_percobaan: attempts, kunci_tampil: outcome === 3,
          keterangan: outcome === 1 ? "Tepat di percobaan ke-1" : outcome === 2 ? "Tepat di percobaan ke-2" : outcome === 3 ? "Kunci ditampilkan" : "Tidak dikerjakan"
        };
      });
      var crr = Math.round((per.t1 + per.t2 + per.t3 + per.ks) / 4);
      return {
        versi: 1, tema: "Hukum Archimedes", contoh: true,
        siswa: { nama: nm, kelas: kelas, no_absen: String(idx + 1) },
        mulai: new Date(start).toISOString(), selesai: new Date(t + 60000).toISOString(),
        durasi_detik: Math.round((t + 60000 - start) / 1000), waktu_habis: idx === 7,
        skor: { CRR: crr, PBR: per.pl, per_bagian: per }, bagian: bagian,
        refleksi: { pertanyaan: C.refleksi, jawaban: [
          pickOne(["Saya mengubah kalimat tentang gelas sirup setelah melihat gambar lagi.", "Saya mengganti hubungan massa jenis karena pesan umpan baliknya.", "Tidak banyak, hanya memperbaiki satu kalimat."]),
          pickOne(["Melihat angka massa jenis pada gambar.", "Pertanyaan pengarah di percobaan pertama.", "Mengingat percobaan gelas berpancuran."])
        ] },
        log_percobaan: log
      };
    });
  }

  /* ------------------------- hitung ------------------------- */
  function filtered() {
    var q = ui.q.trim().toLowerCase();
    var out = store.records.filter(function (r) {
      return (!ui.kelas || r.siswa.kelas === ui.kelas) && (!q || r.siswa.nama.toLowerCase().indexOf(q) >= 0);
    });
    var s = ui.sort;
    out.sort(function (a, b) {
      if (s === "nama") return a.siswa.nama.localeCompare(b.siswa.nama, "id");
      if (s === "crr-desc") return b.skor.CRR - a.skor.CRR || a.siswa.nama.localeCompare(b.siswa.nama, "id");
      if (s === "crr-asc") return a.skor.CRR - b.skor.CRR || a.siswa.nama.localeCompare(b.siswa.nama, "id");
      return String(b.selesai || b.mulai).localeCompare(String(a.selesai || a.mulai));
    });
    return out;
  }
  function usedKey(r) {
    return ORDER.some(function (id) { return r.bagian && r.bagian[id] && r.bagian[id].kunci_tampil; });
  }
  function errorCodes(r) {
    var seen = {}, out = [];
    r.log_percobaan.forEach(function (l) {
      l.kalimat.forEach(function (k) { if (k.kode && !seen[k.kode]) { seen[k.kode] = true; out.push(k.kode); } });
    });
    return out;
  }
  function kodeNama(code) { return C.kodeKesalahan[code] || ""; }

  function stats(rs) {
    var n = rs.length;
    var durs = rs.map(dur).filter(function (x) { return x != null; });
    var perSec = ORDER.map(function (id) {
      var sk = rs.map(function (r) { return r.skor.per_bagian[id] || 1; });
      return { id: id, mean: mean(sk), first: sk.filter(function (x) { return x === 4; }).length, n: n };
    });
    var codeCount = {};
    rs.forEach(function (r) { errorCodes(r).forEach(function (c) { codeCount[c] = (codeCount[c] || 0) + 1; }); });
    var errs = Object.keys(codeCount).map(function (c) { return { code: c, n: codeCount[c], p: codeCount[c] / n }; })
      .sort(function (a, b) { return b.n - a.n || a.code.localeCompare(b.code); }).slice(0, 8);
    var conf = [1, 2, 3, 4].map(function (v) { return { v: v, n: 0, ok: 0 }; });
    rs.forEach(function (r) {
      r.log_percobaan.forEach(function (l) {
        if (l.percobaan === 1 && l.keyakinan >= 1 && l.keyakinan <= 4) {
          var c = conf[l.keyakinan - 1]; c.n++; if (l.status === "lengkap") c.ok++;
        }
      });
    });
    return {
      n: n, crr: mean(rs.map(function (r) { return r.skor.CRR; })), pbr: mean(rs.map(function (r) { return r.skor.PBR; })),
      kunci: n ? rs.filter(usedKey).length / n : 0, dur: durs.length ? mean(durs) : null,
      perSec: perSec, errs: errs, conf: conf
    };
  }

  /* ------------------------- tampilan ------------------------- */
  function pill(s) { return '<span class="pill s' + s + '">' + s + "</span>"; }

  function bars(rows, opts) {
    // rows: {nm, pctW, val, sub, title, cls}
    return '<div class="bars">' + rows.map(function (r) {
      return '<div class="brow" title="' + esc(r.title || "") + '"><span class="nm">' + esc(r.nm) + '</span><div class="track"><div class="fill ' + (r.cls || "") + '" style="width:' + Math.max(0, Math.min(100, r.w)) + '%"></div></div><span class="val">' + esc(r.val) + (r.sub ? "<small>" + esc(r.sub) + "</small>" : "") + "</span></div>";
    }).join("") + "</div>";
  }

  function topbar() {
    var kelasList = [];
    store.records.forEach(function (r) { if (kelasList.indexOf(r.siswa.kelas) < 0) kelasList.push(r.siswa.kelas); });
    kelasList.sort();
    var h = '<header class="topbar"><div class="topbar-in"><div class="brand">Dasbor Guru<small>ILT Hukum Archimedes</small></div><div class="steps"></div>';
    if (store.demo) h += '<span class="demo-tag">Data contoh</span>';
    h += '<button class="btn small ghost" data-act="pick-file">Impor .json</button>';
    if (store.records.length) h += '<button class="btn-quit" data-act="clear-ask">Hapus data</button>';
    h += '<input type="file" id="file" accept=".json,application/json" multiple class="hidden"></div></header>';
    return { html: h, kelas: kelasList };
  }

  function viewEmpty() {
    return '<main class="wrap"><section class="card empty-hero"><div class="kicker">Belum ada data</div><h2>Impor hasil siswa</h2>' +
      "<p>Kumpulkan file <b>hasil-ILT-Archimedes-….json</b> dari siswa, lalu impor beberapa sekaligus. Data hanya disimpan di browser ini dan tidak dikirim ke mana pun.</p>" +
      '<div class="drop" id="drop">Tarik file .json ke sini, atau tekan tombol di bawah</div>' +
      '<div class="actions"><button class="btn" data-act="pick-file">Pilih file .json</button><button class="btn ghost" data-act="demo">Lihat data contoh</button></div></section></main>';
  }

  function viewDash() {
    var rs = filtered(), st = stats(rs), tb = topbar();
    var h = '<main class="wrap"><section class="card"><div class="g-tools">' +
      '<select id="f-kelas" aria-label="Filter kelas"><option value="">Semua kelas</option>' +
      tb.kelas.map(function (k) { return '<option value="' + esc(k) + '"' + (ui.kelas === k ? " selected" : "") + ">" + esc(k) + "</option>"; }).join("") + "</select>" +
      '<input type="search" id="f-q" placeholder="Cari nama siswa" value="' + esc(ui.q) + '" aria-label="Cari nama">' +
      '<select id="f-sort" aria-label="Urutkan">' +
      [["terbaru", "Terbaru"], ["nama", "Nama A–Z"], ["crr-desc", "CRR tertinggi"], ["crr-asc", "CRR terendah"]].map(function (o) {
        return '<option value="' + o[0] + '"' + (ui.sort === o[0] ? " selected" : "") + ">" + o[1] + "</option>";
      }).join("") + "</select><span class=\"spacer\"></span>" +
      '<button class="btn small ghost" data-act="dl-csv"' + (rs.length ? "" : " disabled") + ">⬇ Unduh Excel (CSV)</button></div></section>";

    if (!rs.length) {
      return tb.html + h + '<section class="card"><p class="note-empty">Tidak ada siswa yang cocok dengan filter.</p></section></main>';
    }

    h += '<div class="kpis">' +
      kpi(st.n, "Jumlah siswa") + kpi(f1(st.crr), "Rata-rata CRR", "/ 4") + kpi(f1(st.pbr), "Rata-rata PBR", "/ 4") +
      kpi(pct(st.kunci), "Pernah melihat kunci") + kpi(st.dur == null ? "–" : f1(st.dur), "Rata-rata durasi", " menit") + "</div>";

    // grafik 1: skor per bagian
    var g1 = bars(st.perSec.map(function (s) {
      return { nm: NAMA[s.id], w: (s.mean - 1) / 3 * 100 + 4, val: f1(s.mean), sub: s.first + "/" + s.n + " langsung tepat", title: NAMA[s.id] + ": rata-rata skor " + f1(s.mean) + " dari 4; " + s.first + " dari " + s.n + " siswa tepat di percobaan ke-1" };
    }));
    // grafik 2: kesalahan
    var g2 = st.errs.length ? bars(st.errs.map(function (e) {
      return { nm: e.code, w: e.p * 100, val: pct(e.p), sub: e.n + " siswa", cls: "bad", title: e.code + ": " + kodeNama(e.code) + " (" + e.n + " siswa)" };
    })) : '<p class="note-empty">Belum ada kesalahan tercatat.</p>';
    var g2legend = st.errs.length ? '<div class="note" style="margin-top:10px">' + st.errs.slice(0, 4).map(function (e) { return "<b>" + esc(e.code) + "</b> " + esc(kodeNama(e.code)); }).join("<br>") + "</div>" : "";
    // grafik 3: keyakinan vs ketepatan
    var g3 = bars(st.conf.map(function (c) {
      var p = c.n ? c.ok / c.n : 0;
      return { nm: c.v + " · " + KEYAKINAN[c.v - 1], w: p * 100, val: c.n ? pct(p) : "–", sub: "n = " + c.n, cls: c.v === 4 && c.n && p < .5 ? "warn" : "", title: "Keyakinan " + c.v + ": " + (c.n ? c.ok + " dari " + c.n + " percobaan ke-1 langsung tepat" : "belum ada data") };
    }));

    h += '<div class="charts">' +
      '<section class="card"><h3>Rata-rata skor per bagian</h3><p class="how">Panjang batang = rata-rata skor 1–4. Bagian dengan batang terpendek perlu dibahas ulang.</p>' + g1 + "</section>" +
      '<section class="card"><h3>Kesalahan yang paling sering</h3><p class="how">Persentase siswa yang pernah melakukan jenis kesalahan itu (minimal sekali).</p>' + g2 + g2legend + "</section>" +
      '<section class="card"><h3>Keyakinan vs ketepatan</h3><p class="how">Persentase yang langsung tepat di percobaan ke-1 untuk tiap tingkat keyakinan. Keyakinan 4 dengan persentase rendah menandakan kemungkinan miskonsepsi.</p>' + g3 + "</section></div>";

    h += '<section class="card" style="margin-top:14px"><h3>Daftar siswa (' + rs.length + ')</h3><div class="table-wrap"><table class="stu"><thead><tr><th>Nama</th>' +
      ORDER.map(function (id) { return '<th class="c">' + NAMA[id] + "</th>"; }).join("") +
      '<th class="c">CRR</th><th class="c">PBR</th><th class="c">Durasi</th><th class="c">Kunci</th></tr></thead><tbody>' +
      rs.map(function (r, i) {
        var d = dur(r), k = usedKey(r);
        return '<tr class="r" tabindex="0" data-act="detail" data-id="' + esc(rid(r)) + '"><td class="nm"><b>' + esc(r.siswa.nama) + "</b><span>" + esc(r.siswa.kelas) + (r.siswa.no_absen ? " · absen " + esc(r.siswa.no_absen) : "") + (r.waktu_habis ? " · waktu habis" : "") + "</span></td>" +
          ORDER.map(function (id) {
            var b = r.bagian && r.bagian[id];
            return '<td class="c" title="' + esc(b ? b.keterangan + " (" + b.jumlah_percobaan + " percobaan)" : "") + '">' + pill(r.skor.per_bagian[id] || 1) + "</td>";
          }).join("") +
          '<td class="c"><b>' + r.skor.CRR + '</b></td><td class="c"><b>' + r.skor.PBR + '</b></td><td class="c">' + (d == null ? "–" : f1(d) + " mnt") + '</td><td class="c">' + (k ? '<span class="key-y">Ya</span>' : "–") + "</td></tr>";
      }).join("") + "</tbody></table></div></section></main>";
    return tb.html + h;
  }
  function kpi(v, l, unit) {
    return '<div class="kpi"><div class="v">' + esc(v) + (unit ? "<small>" + esc(unit) + "</small>" : "") + '</div><div class="l">' + esc(l) + "</div></div>";
  }

  function detailHtml(r) {
    var h = '<div class="overlay" data-act="detail-bg"><div class="modal wide" role="dialog" aria-modal="true"><div class="dt-head"><div><h3>' + esc(r.siswa.nama) + "</h3><p>" +
      esc(r.siswa.kelas) + (r.siswa.no_absen ? " · absen " + esc(r.siswa.no_absen) : "") + " · " + tgl(r.mulai) + (dur(r) != null ? " · " + f1(dur(r)) + " menit" : "") +
      '</p></div><button class="x" data-act="detail-close" aria-label="Tutup">×</button></div>' +
      '<div class="dt-scores"><div class="s">CRR ' + r.skor.CRR + "<small>Penalaran ilmiah</small></div><div class=\"s\">PBR " + r.skor.PBR + "<small>Penalaran peluang</small></div>" +
      ORDER.map(function (id) { return '<div class="s">' + pill(r.skor.per_bagian[id] || 1) + "<small>" + NAMA[id] + "</small></div>"; }).join("") + "</div>";
    ORDER.forEach(function (id) {
      var ls = r.log_percobaan.filter(function (l) { return l.layar === id; });
      var b = r.bagian && r.bagian[id];
      h += '<div class="att-h">' + NAMA[id] + (b ? " · " + esc(b.keterangan) : "") + "</div>";
      if (!ls.length) h += '<p class="note-empty">Tidak ada percobaan.</p>';
      ls.forEach(function (l) {
        h += '<div class="att"><div class="att-top"><span class="no">Percobaan ke-' + l.percobaan + '</span><span class="chip-s ' + esc(l.status) + '">' + esc(l.status_teks) + "</span>" +
          "<span>Keyakinan " + l.keyakinan + " (" + esc(KEYAKINAN[l.keyakinan - 1] || "") + ")</span>" + (l.kunci_tampil ? '<span class="chip-k">Kunci ditampilkan</span>' : "") + "</div><ul>" +
          l.kalimat.map(function (k) {
            return "<li>" + (k.benar ? '<span class="ok">✓</span>' : '<span class="no-x">✗</span>') + " " + esc(k.teks) + (k.kode ? ' <code title="' + esc(kodeNama(k.kode)) + '">' + esc(k.kode) + "</code>" : "") + "</li>";
          }).join("") + "</ul>" +
          (l.kode_pesan && l.kode_pesan.length ? '<div class="msg">Pesan: ' + esc(l.kode_pesan.join(", ")) + "</div>" : "") + "</div>";
      });
    });
    var q = (r.refleksi && r.refleksi.pertanyaan) || C.refleksi, a = (r.refleksi && r.refleksi.jawaban) || [];
    h += '<div class="att-h">Refleksi</div>';
    q.forEach(function (t, i) { h += '<div class="refl-q">' + (i + 1) + ". " + esc(t) + '</div><div class="refl-a">' + esc(a[i] || "(kosong)") + "</div>"; });
    return h + "</div></div>";
  }

  function confirmClear() {
    return '<div class="overlay"><div class="modal"><h3>Hapus semua data?</h3><p>Semua hasil yang sudah diimpor dihapus dari browser ini. File .json aslinya tidak terpengaruh.</p>' +
      '<div class="actions"><button class="btn ghost" data-act="modal-no">Batal</button><button class="btn red" data-act="clear-yes">Ya, hapus</button></div></div></div>';
  }

  function render() {
    var app = $("#app");
    var html;
    if (!store.records.length) html = topbar().html + viewEmpty();
    else html = viewDash();
    if (ui.detail) {
      var r = store.records.filter(function (x) { return rid(x) === ui.detail; })[0];
      if (r) html += detailHtml(r);
    }
    if (ui.modal === "clear") html += confirmClear();
    var keep = document.activeElement && document.activeElement.id;
    var pos = keep === "f-q" ? document.activeElement.selectionStart : null;
    app.innerHTML = html;
    if (keep === "f-q") { var el = $("#f-q"); el.focus(); try { el.setSelectionRange(pos, pos); } catch (e) { /* abaikan */ } }
    bindDrop();
  }

  /* ------------------------- unduh ------------------------- */
  function csvEsc(v) { v = v == null ? "" : String(v); return /[";\r\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }
  function exportCsv() {
    var rs = filtered();
    var head = ["nama", "kelas", "no_absen", "mulai", "selesai", "durasi_menit", "waktu_habis"];
    ORDER.forEach(function (id) { head.push("skor_" + id); });
    head.push("CRR", "PBR");
    ORDER.forEach(function (id) { head.push("percobaan_" + id); });
    head.push("kunci_tampil", "kode_kesalahan", "refleksi_1", "refleksi_2");
    var rows = [head].concat(rs.map(function (r) {
      var d = dur(r);
      var row = [r.siswa.nama, r.siswa.kelas, r.siswa.no_absen, r.mulai, r.selesai, d == null ? "" : d.toFixed(1).replace(".", ","), r.waktu_habis ? "ya" : "tidak"];
      ORDER.forEach(function (id) { row.push(r.skor.per_bagian[id]); });
      row.push(r.skor.CRR, r.skor.PBR);
      ORDER.forEach(function (id) { row.push(r.bagian && r.bagian[id] ? r.bagian[id].jumlah_percobaan : ""); });
      row.push(ORDER.filter(function (id) { return r.bagian && r.bagian[id] && r.bagian[id].kunci_tampil; }).map(function (id) { return NAMA[id]; }).join(", "),
        errorCodes(r).join(", "), (r.refleksi && r.refleksi.jawaban && r.refleksi.jawaban[0]) || "", (r.refleksi && r.refleksi.jawaban && r.refleksi.jawaban[1]) || "");
      return row;
    }));
    var csv = "﻿" + rows.map(function (r) { return r.map(csvEsc).join(";"); }).join("\r\n");
    var blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    var url = URL.createObjectURL(blob), a = document.createElement("a");
    a.href = url; a.download = "rekap-ILT-Archimedes-" + slug(ui.kelas || "semua-kelas") + ".csv";
    document.body.appendChild(a); a.click();
    setTimeout(function () { document.body.removeChild(a); URL.revokeObjectURL(url); }, 500);
  }

  /* ------------------------- toast & event ------------------------- */
  var tt;
  function toast(msg) {
    var t = $(".toast");
    if (!t) { t = document.createElement("div"); t.className = "toast"; t.setAttribute("role", "status"); document.body.appendChild(t); }
    t.textContent = msg; clearTimeout(tt);
    tt = setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 3500);
  }
  function bindDrop() {
    var d = $("#drop");
    if (!d) return;
    d.addEventListener("dragover", function (e) { e.preventDefault(); d.classList.add("over"); });
    d.addEventListener("dragleave", function () { d.classList.remove("over"); });
    d.addEventListener("drop", function (e) { e.preventDefault(); d.classList.remove("over"); importFiles(e.dataTransfer.files); });
  }

  document.addEventListener("click", function (ev) {
    var el = ev.target.closest("[data-act]");
    if (!el) return;
    var act = el.getAttribute("data-act");
    switch (act) {
      case "pick-file": $("#file").click(); break;
      case "demo": store = { records: demoRecords(), demo: true }; saveStore(); render(); break;
      case "dl-csv": exportCsv(); break;
      case "detail": ui.detail = el.getAttribute("data-id"); render(); break;
      case "detail-close": ui.detail = null; render(); break;
      case "detail-bg": if (ev.target === el) { ui.detail = null; render(); } break;
      case "clear-ask": ui.modal = "clear"; render(); break;
      case "modal-no": ui.modal = null; render(); break;
      case "clear-yes": store = { records: [], demo: false }; ui = { kelas: "", q: "", sort: "terbaru", detail: null, modal: null }; saveStore(); render(); break;
    }
  });
  document.addEventListener("change", function (ev) {
    var t = ev.target;
    if (t.id === "file") { importFiles(t.files); t.value = ""; }
    else if (t.id === "f-kelas") { ui.kelas = t.value; render(); }
    else if (t.id === "f-sort") { ui.sort = t.value; render(); }
  });
  document.addEventListener("input", function (ev) {
    if (ev.target.id === "f-q") { ui.q = ev.target.value; render(); }
  });
  document.addEventListener("keydown", function (ev) {
    if (ev.key === "Escape" && (ui.detail || ui.modal)) { ui.detail = null; ui.modal = null; render(); }
    if (ev.key === "Enter" && ev.target.matches && ev.target.matches("tr.r")) { ui.detail = ev.target.getAttribute("data-id"); render(); }
  });
  window.addEventListener("dragover", function (e) { e.preventDefault(); });
  window.addEventListener("drop", function (e) {
    if (e.target.closest && e.target.closest("#drop")) return;
    e.preventDefault();
    if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) importFiles(e.dataTransfer.files);
  });

  render();
})();
