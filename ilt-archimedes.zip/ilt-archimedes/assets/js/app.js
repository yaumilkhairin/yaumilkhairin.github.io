/* =====================================================================
   app.js  -  mesin ILT Hukum Archimedes (versi siswa, hasil diunduh)
   Alur: Pengantar -> Tabel 1 -> Tabel 2 -> Tabel 3 -> Kesimpulan -> Peluang -> Hasil
   ===================================================================== */
(function () {
  "use strict";

  var CFG = window.ILT_CONFIG;
  var C = window.ILT_CONTENT;
  var ORDER = ["t1", "t2", "t3", "ks", "pl"];
  var NAMA = { t1: "Tabel 1", t2: "Tabel 2", t3: "Tabel 3", ks: "Kesimpulan", pl: "Peluang" };
  var STATUS_TXT = { salah: "Ada yang salah", belum: "Belum lengkap", lengkap: "Tepat & lengkap" };

  /* ------------------------- util ------------------------- */
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (m) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m];
    });
  }
  function lowerFirst(s) { return s.charAt(0).toLowerCase() + s.slice(1); }
  function $(sel, el) { return (el || document).querySelector(sel); }
  function fill(text, y) { return String(text).replace(/\{Y\}/g, y || ""); }
  function pad2(n) { return (n < 10 ? "0" : "") + n; }
  function iso(t) { return t ? new Date(t).toISOString() : ""; }
  function slug(s) { return String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 30) || "siswa"; }

  /* ------------------------- tabel: nilai bawaan ------------------------- */
  Object.keys(C.tables).forEach(function (id) {
    var T = C.tables[id];
    T.byKey = {};
    T.sentences.forEach(function (s) { T.byKey[s.key] = s; });
    if (!T.slot) T.slot = function (i, oid) { return optOf(this, i, oid).text; };
    if (!T.colLabel) T.colLabel = function (i) { return this.columns[i].label; };
    if (!T.sentence) {
      T.sentence = function (ids) {
        var self = this;
        return ids.map(function (oid, i) {
          var t = optOf(self, i, oid).text;
          return i === 0 ? t : lowerFirst(t);
        }).join(" ");
      };
    }
  });
  function optOf(T, i, id) {
    var os = T.columns[i].options;
    for (var k = 0; k < os.length; k++) if (os[k].id === id) return os[k];
    return { id: id, text: id };
  }
  function defaultSel(T) {
    return T.columns.map(function (c) { return c.options.length === 1 ? c.options[0].id : null; });
  }
  function optEnabled(T, sel, i, id) {
    return T.sentences.some(function (s) {
      var p = s.key.split("|");
      if (p[i] !== id) return false;
      for (var j = 0; j < sel.length; j++) {
        if (j !== i && sel[j] && p[j] !== sel[j]) return false;
      }
      return true;
    });
  }

  /* ------------------------- state ------------------------- */
  var S = load() || fresh();
  var ui = { modal: null, fig: false };
  var lastStage = null;

  function fresh() {
    return {
      v: 1, stage: "intro",
      student: { nama: "", kelas: "", absen: "" },
      startedAt: null, finishedAt: null, timedOut: false,
      screens: {}, log: [], refl: ["", ""], downloaded: false
    };
  }
  function load() {
    try {
      var raw = localStorage.getItem(CFG.storageKey);
      if (raw) { var s = JSON.parse(raw); if (s && s.v === 1) return s; }
    } catch (e) { /* abaikan */ }
    return null;
  }
  function save() {
    try { localStorage.setItem(CFG.storageKey, JSON.stringify(S)); } catch (e) { /* abaikan */ }
  }
  function getSc(id) {
    if (!S.screens[id]) {
      var base = { conf: null, attempts: 0, done: false, doneAttempt: null, keyShown: false, fb: null };
      var extra;
      if (C.tables[id]) extra = { sel: defaultSel(C.tables[id]), list: [], marks: {} };
      else if (id === "ks") extra = { choice: null, wrong: [] };
      else extra = { p1: null, p2: null, mark: null };
      for (var k in extra) base[k] = extra[k];
      S.screens[id] = base;
    }
    return S.screens[id];
  }
  function inProgress() { return ORDER.indexOf(S.stage) >= 0; }

  /* ------------------------- skor ------------------------- */
  function screenScore(id) {
    var sc = S.screens[id];
    if (!sc || (!sc.done && !sc.keyShown)) return 1;
    if (sc.keyShown) return 2;
    return sc.doneAttempt === 1 ? 4 : 3;
  }
  function screenNote(id) {
    var sc = S.screens[id];
    if (!sc || (!sc.done && !sc.keyShown)) return "Tidak dikerjakan";
    if (sc.keyShown) return "Kunci ditampilkan";
    return "Tepat di percobaan ke-" + sc.doneAttempt;
  }
  function summary() {
    var sk = {};
    ORDER.forEach(function (id) { sk[id] = screenScore(id); });
    var crr = Math.round((sk.t1 + sk.t2 + sk.t3 + sk.ks) / 4);
    return { skor: sk, CRR: crr, PBR: sk.pl };
  }

  /* ------------------------- mesin pemeriksa tabel ------------------------- */
  function evalTable(T, list) {
    var items = list.map(function (k) { return { key: k, s: T.byKey[k] }; });
    var wrong = items.filter(function (i) { return !i.s.ok; });
    var met = {};
    items.forEach(function (i) { if (i.s.ok && i.s.core) met[i.s.core] = true; });
    var missing = Object.keys(T.groups).map(Number).filter(function (g) { return !met[g]; });
    var status = wrong.length ? "salah" : (missing.length ? "belum" : "lengkap");
    return { items: items, wrong: wrong, missing: missing, status: status };
  }
  // satu pesan per jenis kesalahan, maksimal dua pesan per percobaan
  function buildMsgs(T, ev, n) {
    var idx = n === 1 ? "a1" : "a2";
    var out = [];
    if (ev.status === "salah") {
      var seen = {};
      for (var i = 0; i < ev.wrong.length; i++) {
        var code = ev.wrong[i].s.err;
        if (seen[code]) continue;
        seen[code] = true;
        out.push({ code: code, text: fill(T.errors[code][idx], ev.wrong[i].s.y) });
        if (out.length >= 2) break;
      }
    } else if (ev.status === "belum") {
      ev.missing.slice(0, 2).forEach(function (g) { out.push({ code: "B" + g, text: T.groups[g][idx] }); });
    } else {
      out.push({ code: "C", text: T.complete });
    }
    return out;
  }
  function buildKey(T, ev) {
    var seen = {}, wrongFix = [];
    ev.wrong.forEach(function (i) {
      var bad = T.sentence(i.key.split("|")), good = T.sentence(i.s.fix.split("|"));
      if (!seen[bad]) { seen[bad] = true; wrongFix.push({ bad: bad, good: good }); }
    });
    var shown = {};
    wrongFix.forEach(function (p) { shown[p.good] = true; });
    var miss = [];
    ev.missing.forEach(function (g) {
      var first = T.sentences.filter(function (s) { return s.ok && s.core === g; })[0];
      var t = T.sentence(first.key.split("|"));
      if (!shown[t]) miss.push(t);        // jangan tampilkan dua kali kalimat yang sama
    });
    return { wrongFix: wrongFix, miss: miss };
  }

  function pushLog(id, n, conf, status, items, codes, msgs, keyShown) {
    S.log.push({
      layar: id, nama_layar: NAMA[id], percobaan: n, waktu: new Date().toISOString(),
      keyakinan: conf, status: status, status_teks: STATUS_TXT[status],
      kalimat: items, kode_pesan: codes, pesan: msgs, kunci_tampil: !!keyShown
    });
  }

  /* ------------------------- aksi pemeriksaan ------------------------- */
  function needConf(sc) {
    if (sc.conf == null) {
      var r = $(".conf-row");
      if (r) { r.classList.remove("shake"); void r.offsetWidth; r.classList.add("shake"); }
      toast("Pilih dulu tingkat keyakinanmu (1–4) sebelum Periksa.");
      return true;
    }
    return false;
  }

  function checkTable(id) {
    var T = C.tables[id], sc = getSc(id);
    if (sc.done) return;
    if (!sc.list.length) { toast("Tambahkan setidaknya satu kalimat dulu."); return; }
    if (needConf(sc)) return;
    var n = ++sc.attempts;
    var ev = evalTable(T, sc.list);
    var msgs = buildMsgs(T, ev, n);
    sc.marks = {};
    ev.items.forEach(function (it) { sc.marks[it.key] = it.s.ok ? "ok" : "bad"; });
    if (ev.status === "lengkap") { sc.done = true; sc.doneAttempt = n; }
    else if (n >= CFG.maxAttempts) sc.keyShown = true;
    var key = (ev.status !== "lengkap" && sc.keyShown) ? buildKey(T, ev) : null;
    sc.fb = { n: n, status: ev.status, msgs: msgs.map(function (m) { return m.text; }), key: key };
    pushLog(id, n, sc.conf, ev.status,
      ev.items.map(function (it) { return { teks: T.sentence(it.key.split("|")), benar: it.s.ok, kode: it.s.ok ? null : it.s.err }; }),
      msgs.map(function (m) { return m.code; }), sc.fb.msgs, !!key);
    sc.conf = null;
    save(); render(); focusFb();
  }

  function checkKs() {
    var K = C.ks, sc = getSc("ks");
    if (sc.done) return;
    if (!sc.choice) { toast("Pilih satu alasan dulu."); return; }
    if (needConf(sc)) return;
    var n = ++sc.attempts;
    var ok = sc.choice === K.key;
    var o = K.options.filter(function (x) { return x.id === sc.choice; })[0];
    var m = K.messages[sc.choice];
    var text = n === 1 ? m.a1 : (m.a2 || m.a1);
    if (ok) { sc.done = true; sc.doneAttempt = n; }
    else {
      if (sc.wrong.indexOf(sc.choice) < 0) sc.wrong.push(sc.choice);
      if (n >= CFG.maxAttempts) sc.keyShown = true;
    }
    var key = (!ok && sc.keyShown) ? { text: K.options.filter(function (x) { return x.id === K.key; })[0].text, msg: K.messages.d.a1 } : null;
    sc.fb = { n: n, status: ok ? "lengkap" : "salah", msgs: [text], key: key };
    pushLog("ks", n, sc.conf, sc.fb.status, [{ teks: o.text, benar: ok, kode: ok ? null : o.err }],
      [ok ? "C" : o.err], [text], !!key);
    sc.conf = null;
    save(); render(); focusFb();
  }

  function checkPl() {
    var P = C.pl, sc = getSc("pl");
    if (sc.done) return;
    if (!sc.p1 || !sc.p2) { toast("Pilih jawaban P.1 dan alasan P.2 dulu."); return; }
    if (needConf(sc)) return;
    var n = ++sc.attempts, idx = n === 1 ? "a1" : "a2";
    var ok1 = sc.p1 === P.p1.key, ok2 = sc.p2 === P.p2.key;
    var o1 = P.p1.options.filter(function (x) { return x.id === sc.p1; })[0];
    var o2 = P.p2.options.filter(function (x) { return x.id === sc.p2; })[0];
    var p2m = ok2 ? null : P.p2.messages[o2.err === "P2-d" ? "d" : "bc"][idx];
    var msgs = [], codes = [];
    if (ok1 && ok2) { msgs.push(P.complete); codes.push("C"); }
    else if (ok1) { msgs.push(P.p1BenarTeks + p2m); codes.push(o2.err); }
    else {
      msgs.push(P.p1.messages[sc.p1][idx]); codes.push("P1-" + sc.p1);
      if (ok2) msgs.push(P.p2BenarTeks);
      else { codes.push(o2.err); if (n >= 2) msgs.push(p2m); }
    }
    sc.mark = { p1: ok1, p2: ok2 };
    var all = ok1 && ok2;
    if (all) { sc.done = true; sc.doneAttempt = n; }
    else if (n >= CFG.maxAttempts) sc.keyShown = true;
    var key = (!all && sc.keyShown)
      ? { text: "P.1: " + P.p1.options[0].text + ". P.2: " + P.p2.options[0].text, msg: P.complete }
      : null;
    sc.fb = { n: n, status: all ? "lengkap" : "salah", msgs: msgs, key: key };
    pushLog("pl", n, sc.conf, sc.fb.status,
      [{ teks: "P.1 " + o1.text, benar: ok1, kode: ok1 ? null : "P1-" + sc.p1 },
       { teks: "P.2 " + o2.text, benar: ok2, kode: ok2 ? null : o2.err }],
      codes, msgs, !!key);
    sc.conf = null;
    save(); render(); focusFb();
  }

  function focusFb() {
    setTimeout(function () {
      var el = document.getElementById("fb");
      if (el && el.scrollIntoView) el.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }, 30);
  }

  /* ------------------------- navigasi ------------------------- */
  function canAdvance(id) { var sc = getSc(id); return sc.done || sc.keyShown; }
  function advance() {
    var i = ORDER.indexOf(S.stage);
    if (i < 0 || !canAdvance(S.stage)) return;
    if (i === ORDER.length - 1) finish(false);
    else { S.stage = ORDER[i + 1]; save(); render(); }
  }
  function finish(timedOut) {
    S.finishedAt = Date.now();
    S.timedOut = !!timedOut;
    S.stage = "hasil";
    ui.modal = null; ui.fig = false;
    save(); render();
  }
  function startTask() {
    if (!S.student.nama.trim() || !S.student.kelas.trim()) { toast("Isi nama lengkap dan kelas dulu."); return; }
    S.startedAt = Date.now();
    S.stage = "t1";
    save(); render();
  }
  function resetAll() {
    S = fresh();
    ui = { modal: null, fig: false };
    save(); render();
  }

  /* ------------------------- timer ------------------------- */
  function remainingMs() {
    if (!CFG.timeLimitMinutes || !S.startedAt) return null;
    return CFG.timeLimitMinutes * 60000 - (Date.now() - S.startedAt);
  }
  function timerText() {
    var r = remainingMs();
    if (r == null) return "";
    r = Math.max(0, Math.ceil(r / 1000));
    return pad2(Math.floor(r / 60)) + ":" + pad2(r % 60);
  }
  function updateTimer() {
    var el = $("#timer");
    if (!el) return;
    var r = remainingMs();
    el.textContent = "⏱ " + timerText();
    el.className = "timer" + (r != null && r < 0 ? " over" : (r != null && r < 5 * 60000 ? " warn" : ""));
  }
  setInterval(function () {
    if (!inProgress()) return;
    var r = remainingMs();
    if (r != null && r <= 0) { finish(true); return; }
    updateTimer();
  }, 1000);

  /* ------------------------- tampilan: bagian umum ------------------------- */
  function topbar() {
    var h = '<header class="topbar"><div class="topbar-in"><div class="brand">' + esc(C.judul) + "<small>Interactive Learning Task</small></div>";
    if (S.stage !== "intro") {
      h += '<nav class="steps">';
      var cur = S.stage === "hasil" ? 5 : ORDER.indexOf(S.stage);
      ORDER.concat(["hasil"]).forEach(function (id, i) {
        var done = i < cur || (id !== "hasil" && S.screens[id] && (S.screens[id].done || S.screens[id].keyShown) && i !== cur);
        var cls = "step" + (i === cur ? " now" : (done ? " done" : ""));
        h += '<span class="' + cls + '"><span class="dot">' + (done ? "✓" : (i + 1)) + "</span>" + (id === "hasil" ? "Hasil" : NAMA[id]) + "</span>";
      });
      h += "</nav>";
      if (inProgress() && CFG.timeLimitMinutes) h += '<div class="timer" id="timer">⏱ ' + timerText() + "</div>";
      h += '<button class="btn-quit" data-act="quit">Keluar</button>';
    }
    return h + "</div></header>";
  }

  function figureHtml(hl) {
    hl = hl || {};
    return '<div class="figure"><img src="' + esc(C.gambar) + '" alt="Tiga gelas berisi alkohol (800 kg/m³), air putih (1.000 kg/m³), dan sirup (1.300 kg/m³). Es batu 900 kg/m³ tenggelam di alkohol, mengapung di air putih dan sirup.">' +
      ["alk", "air", "sir"].map(function (g) { return '<div class="hl hl-' + g + (hl[g] ? " on" : "") + '"></div>'; }).join("") + "</div>";
  }

  function highlights(stage) {
    var hl = {}, T = C.tables[stage];
    if (!T) return hl;
    var sc = getSc(stage);
    sc.sel.forEach(function (id, i) {
      if (!id) return;
      var o = optOf(T, i, id);
      if (o.glass) hl[o.glass] = true;
    });
    return hl;
  }

  function notesHtml(stage) {
    var upto = ORDER.indexOf(stage), h = "";
    for (var i = 0; i < upto; i++) {
      var id = ORDER[i], T = C.tables[id];
      if (!T) continue;
      var sc = S.screens[id];
      if (!sc) continue;
      var ok = sc.list.filter(function (k) { return T.byKey[k].ok; });
      if (!ok.length) continue;
      h += '<div class="tt">' + NAMA[id] + "</div><ul>" +
        ok.map(function (k) { return "<li>" + esc(T.sentence(k.split("|"))) + "</li>"; }).join("") + "</ul>";
    }
    return h ? '<div class="card notes"><h3>Catatanmu</h3>' + h + "</div>" : "";
  }

  function modalHtml() {
    if (!ui.modal) return "";
    if (ui.modal === "quit") {
      return '<div class="overlay"><div class="modal" role="dialog" aria-modal="true"><h3>Keluar dari tugas?</h3>' +
        "<p>Semua jawabanmu di perangkat ini akan dihapus dan kamu mulai dari awal. Jangan keluar kalau hasilmu belum diunduh.</p>" +
        '<div class="actions"><button class="btn ghost" data-act="modal-no">Batal</button><button class="btn red" data-act="quit-yes">Ya, keluar</button></div></div></div>';
    }
    if (ui.modal === "finish") {
      return '<div class="overlay"><div class="modal" role="dialog" aria-modal="true"><h3>Hasilmu belum diunduh</h3>' +
        "<p>Kalau kamu menekan Selesai sekarang, hasilmu hilang dari perangkat ini. Unduh file hasil dulu supaya bisa diserahkan ke guru.</p>" +
        '<div class="actions"><button class="btn ghost" data-act="modal-no">Kembali</button><button class="btn red" data-act="quit-yes">Tetap selesai</button></div></div></div>';
    }
    return "";
  }

  function shell(stage, inner) {
    var T = C.tables[stage];
    var showSide = stage !== "pl";
    var h = topbar();
    h += '<main class="wrap">';
    if (showSide) {
      h += '<div class="layout"><aside class="side"><div class="card" style="padding:12px">' + figureHtml(highlights(stage)) + "</div>" + notesHtml(stage) + '</aside><div class="work">' + inner + "</div></div>";
      h += '<button class="fab" data-act="fig">🖼 Gambar</button>';
      if (ui.fig) {
        h += '<div class="sheet" data-act="fig-close-bg"><div class="sheet-in"><div class="sheet-head"><h3>Gambar soal</h3><button class="x" data-act="fig-close" aria-label="Tutup">×</button></div>' +
          figureHtml(highlights(stage)) + notesHtml(stage) + "</div></div>";
      }
    } else {
      h += '<div class="work" style="max-width:820px;margin:0 auto">' + inner + "</div>";
    }
    h += "</main>";
    return h;
  }

  /* ------------------------- tampilan: pengantar ------------------------- */
  function viewIntro() {
    var h = topbar() + '<main class="wrap"><div class="intro">';
    h += '<section class="card"><div class="intro-hero"><div><div class="kicker">Interactive Learning Task</div>' +
      "<h1>Hukum Archimedes: Es Batu di Tiga Gelas</h1>" +
      '<p class="question">' + esc(C.soalUtama) + "</p></div>" + figureHtml() + "</div></section>";
    h += '<section class="card"><h2>Cara mengerjakan</h2><ol class="howto">' +
      C.caraMengerjakan.map(function (t) { return "<li><span>" + esc(t) + "</span></li>"; }).join("") + "</ol>" +
      '<div class="example"><b>Contoh kotak kalimat</b><div class="row">' +
      '<span class="mini">Es batu</span><span class="mini on">mengapung</span><span class="mini">di sirup</span>' +
      "</div></div></section>";
    h += '<section class="card"><h2>Yang akan kamu kerjakan</h2><table class="plan">' +
      C.bagian.map(function (b) {
        return "<tr><td><b>" + esc(b.nama) + "</b> · " + esc(b.ket) + "</td><td>±" + b.menit + " menit</td></tr>";
      }).join("") +
      '<tr><td><b>Pengantar dan penutup</b></td><td>±5 menit</td></tr></table>' +
      '<p class="note">Total ±' + (CFG.timeLimitMinutes || 25) + " menit. Jawabanmu tersimpan otomatis di perangkat ini.</p></section>";
    h += '<section class="card"><h2>Isi identitasmu</h2><form class="ident" id="ident" autocomplete="off">' +
      '<div class="field"><label for="f-nama">Nama lengkap</label><input id="f-nama" data-f="nama" value="' + esc(S.student.nama) + '" required></div>' +
      '<div class="grid2"><div class="field"><label for="f-kelas">Kelas</label><input id="f-kelas" data-f="kelas" placeholder="contoh: XI IPA 2" value="' + esc(S.student.kelas) + '" required></div>' +
      '<div class="field"><label for="f-absen">No. absen <span class="opt">(boleh dikosongkan)</span></label><input id="f-absen" data-f="absen" inputmode="numeric" value="' + esc(S.student.absen) + '"></div></div>' +
      '<div class="actions" style="justify-content:flex-start"><button type="submit" class="btn" id="btn-start" data-act="start">Mulai</button>' +
      '<span class="note" style="margin:0">Waktu ' + (CFG.timeLimitMinutes || 25) + " menit mulai berjalan setelah tombol ini ditekan.</span></div></form></section>";
    return h + "</div></main>";
  }

  /* ------------------------- tampilan: komponen jawaban ------------------------- */
  function confHtml(sc) {
    return '<div class="confidence"><h3>Seberapa yakin kamu dengan jawabanmu?</h3><div class="conf-row">' +
      C.keyakinan.map(function (t, i) {
        return '<button class="conf' + (sc.conf === i + 1 ? " on" : "") + '" data-act="conf" data-v="' + (i + 1) + '"><b>' + (i + 1) + "</b><span>" + esc(t) + "</span></button>";
      }).join("") + "</div></div>";
  }

  function fbHtml(sc, T) {
    var fb = sc.fb;
    if (!fb) return "";
    var head = { salah: "Ada yang salah", belum: "Hampir lengkap", lengkap: "Hebat!" }[fb.status];
    var h = '<div class="fb ' + fb.status + '" id="fb"><div class="fb-head"><span class="badge ' + fb.status + '">' + head + '</span><span class="ke">Percobaan ke-' + fb.n + "</span></div><ul>" +
      fb.msgs.map(function (m) { return "<li>" + esc(m) + "</li>"; }).join("") + "</ul>";
    if (fb.key) {
      h += '<div class="key"><h3>Kalimat yang tepat</h3>';
      if (T) {
        fb.key.wrongFix.forEach(function (p) {
          h += '<div class="pair"><span class="bad">' + esc(p.bad) + '</span><span class="good">✓ ' + esc(p.good) + "</span></div>";
        });
        if (fb.key.miss.length) {
          h += '<div class="miss-t">Hal inti yang belum kamu sebut:</div>';
          fb.key.miss.forEach(function (m) { h += '<div class="good">✓ ' + esc(m) + "</div>"; });
        }
        h += '<p class="foot">' + esc(T.keyFooter) + "</p>";
      } else {
        h += '<div class="pair"><span class="good">' + esc(fb.key.text) + "</span></div>";
        if (fb.key.msg) h += '<p class="foot">' + esc(fb.key.msg) + "</p>";
      }
      h += "</div>";
    }
    return h + "</div>";
  }

  function nextRow(id) {
    var last = ORDER.indexOf(id) === ORDER.length - 1;
    return '<button class="btn green" data-act="next">' + (last ? "Lihat hasil" : "Lanjut") + " →</button>";
  }

  /* ------------------------- tampilan: tabel kalimat ------------------------- */
  function viewTable(id) {
    var T = C.tables[id], sc = getSc(id), locked = sc.done;
    var bagian = C.bagian.filter(function (b) { return b.id === id; })[0];
    var h = '<section class="card"><div class="kicker">' + (ORDER.indexOf(id) + 1) + " dari 5 · ±" + bagian.menit + " menit</div><h2>" + esc(T.judul) + '</h2><p class="lead">' + esc(T.petunjuk) + "</p>";
    if (!locked) {
      var sel = sc.sel, ready = sel.every(Boolean);
      h += '<div class="sentence-row' + (ready ? " ready" : "") + '" data-drop="' + id + '">';
      T.columns.forEach(function (col, i) {
        var conn = T.connectors && T.connectors[i];
        if (conn) h += '<span class="conn">' + esc(conn) + "</span>";
        if (sel[i]) h += '<button class="slot filled" data-act="unpick" data-col="' + i + '" title="Ketuk untuk mengosongkan">' + esc(T.slot(i, sel[i], sel)) + "</button>";
        else h += '<span class="slot empty">' + esc(T.colLabel(i, sel)) + "</span>";
      });
      h += "</div>";
      h += '<div class="cols" style="--n:' + T.columns.length + '">';
      T.columns.forEach(function (col, i) {
        h += '<div class="col"><div class="col-label">' + esc(T.colLabel(i, sel)) + '</div><div class="col-opts">';
        col.options.forEach(function (o) {
          var dis = !optEnabled(T, sel, i, o.id), on = sel[i] === o.id;
          h += '<button class="chip' + (on ? " on" : "") + (dis ? " off" : "") + '" data-act="pick" data-col="' + i + '" data-opt="' + o.id + '"' +
            (dis ? ' aria-disabled="true"' : ' draggable="true"') + ">" + esc(o.text) + "</button>";
        });
        h += "</div></div>";
      });
      h += "</div>";
      h += '<div class="actions"><button class="btn ghost small" data-act="clear">Kosongkan</button>' +
        '<button class="btn small' + (ready ? "" : " disabled") + '" data-act="add"' + (ready ? "" : " disabled") + ">+ Tambahkan kalimat</button></div>";
      h += '<p class="note">' + esc(T.catatan) + "</p>";
    }
    h += "</section>";

    h += '<section class="card answers"><h3>Kalimat jawabanmu</h3>';
    if (!sc.list.length) h += '<div class="empty-state">Belum ada kalimat. Susun kalimat di atas lalu tekan + Tambahkan kalimat.</div>';
    else {
      h += "<ol>";
      sc.list.forEach(function (k, i) {
        var m = sc.marks[k];
        h += '<li class="ans' + (m ? " " + m : "") + '"><span class="mark">' + (m === "ok" ? "✓" : m === "bad" ? "✗" : (i + 1)) + '</span><span class="txt">' + esc(T.sentence(k.split("|"))) + "</span>";
        if (!locked) h += '<button class="icon-btn" data-act="edit" data-i="' + i + '" title="Ubah" aria-label="Ubah kalimat">✎</button><button class="icon-btn" data-act="del" data-i="' + i + '" title="Hapus" aria-label="Hapus kalimat">×</button>';
        h += "</li>";
      });
      h += "</ol>";
    }
    if (!locked) {
      h += confHtml(sc);
      h += '<div class="check-row"><span class="count">' + (sc.attempts ? "Sudah diperiksa " + sc.attempts + "×" : "Belum diperiksa") + "</span><span>" +
        (sc.keyShown ? '<button class="btn ghost" data-act="next" style="margin-right:8px">' + (ORDER.indexOf(id) === ORDER.length - 1 ? "Lihat hasil" : "Lanjut") + " →</button>" : "") +
        '<button class="btn" data-act="check">Periksa</button></span></div>';
    }
    h += "</section>";
    if (sc.fb) h += '<div class="work-fb" style="margin-top:14px">' + fbHtml(sc, T) + "</div>";
    if (locked) h += '<div class="actions">' + nextRow(id) + "</div>";
    return h;
  }

  /* ------------------------- tampilan: kesimpulan ------------------------- */
  function viewKs() {
    var K = C.ks, sc = getSc("ks"), locked = sc.done;
    var h = '<section class="card"><div class="kicker">4 dari 5 · ±2 menit</div><h2>' + esc(K.judul) + '</h2><p class="lead">' + esc(K.petunjuk) + "</p>" +
      '<div class="q-box">' + esc(K.soal) + '</div><div class="choices">';
    K.options.forEach(function (o) {
      var cls = "choice";
      if (locked && o.id === K.key) cls += " good";
      else if (sc.wrong.indexOf(o.id) >= 0) cls += " bad";
      else if (sc.choice === o.id) cls += " on";
      if (sc.keyShown && o.id === K.key) cls += " good";
      h += '<button class="' + cls + '" data-act="choose" data-opt="' + o.id + '"' + (locked ? " disabled" : "") + '><span class="lt">' + o.id + "</span><span>" + esc(o.text) + "</span></button>";
    });
    h += "</div>";
    if (!locked) {
      h += confHtml(sc) + '<div class="check-row"><span class="count">' + (sc.attempts ? "Sudah diperiksa " + sc.attempts + "×" : "Belum diperiksa") + "</span><span>" +
        (sc.keyShown ? '<button class="btn ghost" data-act="next" style="margin-right:8px">Lanjut →</button>' : "") +
        '<button class="btn" data-act="check">Periksa</button></span></div>';
    }
    h += "</section>";
    if (sc.fb) h += '<div style="margin-top:14px">' + fbHtml(sc, null) + "</div>";
    if (locked) h += '<div class="actions">' + nextRow("ks") + "</div>";
    return h;
  }

  /* ------------------------- tampilan: peluang ------------------------- */
  function viewPl() {
    var P = C.pl, sc = getSc("pl"), locked = sc.done;
    function group(name, tag, cfg, field, markKey, text) {
      var m = sc.mark && sc.mark[markKey];
      var res = sc.mark ? (m ? '<span class="res ok">✓</span>' : '<span class="res bad">✗</span>') : "";
      var g = '<div class="sub"><h3><span class="tag">' + tag + "</span>" + esc(name) + " " + res + "</h3>" + (text ? '<p class="lead">' + esc(text) + "</p>" : "") + '<div class="choices">';
      cfg.options.forEach(function (o) {
        var cls = "choice";
        if (sc[field] === o.id) cls += sc.mark ? (m ? " good" : " bad") : " on";
        g += '<button class="' + cls + '" data-act="' + field + '" data-opt="' + o.id + '"' + (locked ? " disabled" : "") + '><span class="lt">' + o.id + "</span><span>" + esc(o.text) + "</span></button>";
      });
      return g + "</div></div>";
    }
    var h = '<section class="card"><div class="kicker">5 dari 5 · ±3 menit</div><h2>' + esc(P.judul) + '</h2><p class="lead">' + esc(P.petunjuk) + "</p>" +
      '<div class="q-box">' + esc(P.soal) + '<table class="data"><thead><tr><th>Benda</th><th>Massa jenis (kg/m³)</th></tr></thead><tbody>' +
      P.benda.map(function (b) { return "<tr><td>" + esc(b[0]) + "</td><td>" + String(b[1]).replace(/\B(?=(\d{3})+(?!\d))/g, ".") + "</td></tr>"; }).join("") +
      "</tbody></table><p style=\"margin-top:10px\"><b>" + esc(P.tanya) + "</b></p></div>";
    h += group("Jawaban", "P.1", P.p1, "p1", "p1", "");
    h += group("Alasan", "P.2", P.p2, "p2", "p2", "Mengapa jawabanmu begitu?");
    if (!locked) {
      h += confHtml(sc) + '<div class="check-row"><span class="count">' + (sc.attempts ? "Sudah diperiksa " + sc.attempts + "×" : "Belum diperiksa") + "</span><span>" +
        (sc.keyShown ? '<button class="btn ghost" data-act="next" style="margin-right:8px">Lihat hasil →</button>' : "") +
        '<button class="btn" data-act="check">Periksa</button></span></div>';
    }
    h += "</section>";
    if (sc.fb) h += '<div style="margin-top:14px">' + fbHtml(sc, null) + "</div>";
    if (locked) h += '<div class="actions">' + nextRow("pl") + "</div>";
    return h;
  }

  /* ------------------------- tampilan: hasil ------------------------- */
  function viewResult() {
    var sm = summary();
    var h = topbar() + '<main class="wrap"><div class="result">';
    if (S.timedOut) h += '<div class="banner">⏰ Waktu ' + CFG.timeLimitMinutes + " menit sudah habis. Bagian yang belum selesai mendapat skor 1. Hasilmu tetap bisa diunduh.</div>";
    h += '<section class="card"><div class="kicker">Selesai</div><h2>Hasil penalaranmu, ' + esc(S.student.nama) + '</h2>' +
      '<div class="scores"><div class="score"><div class="big">' + sm.CRR + '<small> / 4</small></div><div class="lbl">Penalaran ilmiah</div><div class="sm">Rata-rata Tabel 1, 2, 3, dan Kesimpulan</div></div>' +
      '<div class="score"><div class="big">' + sm.PBR + '<small> / 4</small></div><div class="lbl">Penalaran peluang</div><div class="sm">Skor bagian Peluang</div></div></div>' +
      '<table class="tbl"><thead><tr><th>Bagian</th><th>Skor</th><th>Keterangan</th></tr></thead><tbody>' +
      ORDER.map(function (id) {
        var s = sm.skor[id];
        return "<tr><td>" + NAMA[id] + '</td><td><span class="pill s' + s + '">' + s + "</span></td><td>" + esc(screenNote(id)) + "</td></tr>";
      }).join("") + "</tbody></table></section>";
    h += '<section class="card"><h2>Refleksi</h2><p class="lead">Jawab dengan kalimatmu sendiri. Dua-duanya wajib diisi sebelum kamu bisa mengunduh hasil.</p><div class="reflect">' +
      C.refleksi.map(function (q, i) {
        return '<div class="field"><label for="r' + i + '">' + (i + 1) + ". " + esc(q) + '</label><textarea id="r' + i + '" data-f="refl' + i + '" rows="3">' + esc(S.refl[i]) + "</textarea></div>";
      }).join("") + "</div></section>";
    h += '<section class="card"><h2>Unduh hasilmu</h2><p class="lead">Serahkan file hasil ke gurumu. Unduh dulu, baru tekan Selesai.</p><div class="dl">' +
      '<button class="btn dl-btn" data-act="dl-json">⬇ Unduh file hasil (.json)</button>' +
      '<button class="btn ghost dl-btn" data-act="dl-csv">⬇ Ringkasan (.csv)</button>' +
      '<button class="btn ghost dl-btn" data-act="dl-log">⬇ Log percobaan (.csv)</button></div>' +
      '<p class="dl-help">File .json memuat semua percobaan dan refleksimu. File .csv bisa dibuka di Excel.</p>' +
      '<div class="actions"><button class="btn green" data-act="finish">Selesai</button></div></section>';
    return h + "</div></main>";
  }

  /* ------------------------- render ------------------------- */
  function render() {
    var app = $("#app");
    var html;
    if (S.stage === "intro") html = viewIntro();
    else if (S.stage === "hasil") html = viewResult();
    else if (C.tables[S.stage]) html = shell(S.stage, viewTable(S.stage));
    else if (S.stage === "ks") html = shell("ks", viewKs());
    else html = shell("pl", viewPl());
    app.innerHTML = html + modalHtml();
    if (S.stage !== lastStage) { window.scrollTo(0, 0); lastStage = S.stage; }
    refreshGate();
    updateTimer();
  }

  function reflOk() {
    return S.refl.every(function (t) { return t.trim().length >= CFG.minReflectionChars; });
  }
  function refreshGate() {
    var b = $("#btn-start");
    if (b) {
      var ok = S.student.nama.trim() && S.student.kelas.trim();
      b.disabled = !ok; b.classList.toggle("disabled", !ok);
    }
    var ds = document.querySelectorAll(".dl-btn");
    for (var i = 0; i < ds.length; i++) {
      var okr = reflOk();
      ds[i].disabled = !okr; ds[i].classList.toggle("disabled", !okr);
    }
  }

  /* ------------------------- toast ------------------------- */
  var toastTimer;
  function toast(msg) {
    var t = $(".toast");
    if (!t) { t = document.createElement("div"); t.className = "toast"; t.setAttribute("role", "status"); document.body.appendChild(t); }
    t.textContent = msg;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 3200);
  }

  /* ------------------------- unduh ------------------------- */
  function download(name, mime, content) {
    var blob = new Blob([content], { type: mime });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url; a.download = name;
    document.body.appendChild(a); a.click();
    setTimeout(function () { document.body.removeChild(a); URL.revokeObjectURL(url); }, 500);
    S.downloaded = true; save();
  }
  function fileBase() {
    return "hasil-ILT-Archimedes-" + slug(S.student.kelas) + "-" + slug(S.student.nama);
  }
  function csvEsc(v) {
    v = v == null ? "" : String(v);
    return /[";\r\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
  }
  function toCsv(rows) {
    return "﻿" + rows.map(function (r) { return r.map(csvEsc).join(";"); }).join("\r\n");
  }
  function allCodes() {
    var seen = {}, out = [];
    S.log.forEach(function (l) {
      l.kalimat.forEach(function (k) { if (k.kode && !seen[k.kode]) { seen[k.kode] = true; out.push(k.kode); } });
    });
    return out;
  }
  function exportJson() {
    var sm = summary();
    var bagian = {};
    ORDER.forEach(function (id) {
      var sc = S.screens[id];
      bagian[id] = {
        nama: NAMA[id], skor: sm.skor[id], keterangan: screenNote(id),
        jumlah_percobaan: sc ? sc.attempts : 0, kunci_tampil: !!(sc && sc.keyShown)
      };
    });
    return JSON.stringify({
      versi: 1, tema: "Hukum Archimedes",
      siswa: { nama: S.student.nama.trim(), kelas: S.student.kelas.trim(), no_absen: S.student.absen.trim() },
      mulai: iso(S.startedAt), selesai: iso(S.finishedAt),
      durasi_detik: S.startedAt && S.finishedAt ? Math.round((S.finishedAt - S.startedAt) / 1000) : null,
      waktu_habis: S.timedOut,
      skor: { CRR: sm.CRR, PBR: sm.PBR, per_bagian: sm.skor },
      bagian: bagian,
      refleksi: { pertanyaan: C.refleksi, jawaban: S.refl },
      log_percobaan: S.log,
      kode_kesalahan: C.kodeKesalahan
    }, null, 2);
  }
  function exportSummaryCsv() {
    var sm = summary();
    var head = ["nama", "kelas", "no_absen", "mulai", "selesai", "durasi_menit", "waktu_habis"];
    var row = [S.student.nama.trim(), S.student.kelas.trim(), S.student.absen.trim(), iso(S.startedAt), iso(S.finishedAt),
      S.startedAt && S.finishedAt ? ((S.finishedAt - S.startedAt) / 60000).toFixed(1).replace(".", ",") : "", S.timedOut ? "ya" : "tidak"];
    ORDER.forEach(function (id) { head.push("skor_" + id); row.push(sm.skor[id]); });
    head.push("CRR", "PBR"); row.push(sm.CRR, sm.PBR);
    ORDER.forEach(function (id) { head.push("percobaan_" + id); row.push(S.screens[id] ? S.screens[id].attempts : 0); });
    head.push("kunci_tampil", "kode_kesalahan", "refleksi_1", "refleksi_2");
    row.push(ORDER.filter(function (id) { return S.screens[id] && S.screens[id].keyShown; }).map(function (id) { return NAMA[id]; }).join(", "),
      allCodes().join(", "), S.refl[0].trim(), S.refl[1].trim());
    return toCsv([head, row]);
  }
  function exportLogCsv() {
    var rows = [["nama", "kelas", "layar", "percobaan", "waktu", "keyakinan", "status", "kalimat", "kode_pesan", "pesan", "kunci_tampil"]];
    S.log.forEach(function (l) {
      rows.push([S.student.nama.trim(), S.student.kelas.trim(), l.nama_layar, l.percobaan, l.waktu, l.keyakinan, l.status_teks,
        l.kalimat.map(function (k) { return k.teks + " [" + (k.benar ? "✓" : "✗" + (k.kode ? " " + k.kode : "")) + "]"; }).join(" | "),
        l.kode_pesan.join(", "), l.pesan.join(" | "), l.kunci_tampil ? "ya" : "tidak"]);
    });
    return toCsv(rows);
  }

  /* ------------------------- aksi ------------------------- */
  function pick(i, oid) {
    var id = S.stage, T = C.tables[id], sc = getSc(id);
    if (sc.done || T.columns[i].options.length === 1) return;
    if (sc.sel[i] === oid) sc.sel[i] = null;
    else {
      if (!optEnabled(T, sc.sel, i, oid)) {
        toast("Kotak itu tidak bisa dipasangkan dengan pilihanmu. Ketuk kotak biru di baris kalimat untuk mengosongkannya.");
        return;
      }
      sc.sel[i] = oid;
    }
    save(); render();
  }
  function onClick(ev) {
    var el = ev.target.closest("[data-act]");
    if (!el) return;
    var act = el.getAttribute("data-act");
    if (el.disabled || el.getAttribute("aria-disabled") === "true" && act !== "pick") return;
    var id = S.stage, sc, T = C.tables[id];
    switch (act) {
      case "start": ev.preventDefault(); startTask(); break;
      case "pick": pick(+el.getAttribute("data-col"), el.getAttribute("data-opt")); break;
      case "unpick":
        sc = getSc(id);
        sc.sel[+el.getAttribute("data-col")] = null; save(); render(); break;
      case "clear": sc = getSc(id); sc.sel = defaultSel(T); save(); render(); break;
      case "add":
        sc = getSc(id);
        if (!sc.sel.every(Boolean)) return;
        var key = sc.sel.join("|");
        if (sc.list.indexOf(key) >= 0) { toast("Kalimat itu sudah ada di daftarmu."); return; }
        sc.list.push(key); sc.sel = defaultSel(T); save(); render(); break;
      case "edit":
        sc = getSc(id);
        var k = sc.list.splice(+el.getAttribute("data-i"), 1)[0];
        delete sc.marks[k]; sc.sel = k.split("|"); save(); render();
        break;
      case "del":
        sc = getSc(id);
        var k2 = sc.list.splice(+el.getAttribute("data-i"), 1)[0];
        delete sc.marks[k2]; save(); render(); break;
      case "conf": sc = getSc(id); sc.conf = +el.getAttribute("data-v"); save(); render(); break;
      case "choose": sc = getSc("ks"); if (sc.done) return; sc.choice = el.getAttribute("data-opt"); save(); render(); break;
      case "p1": case "p2":
        sc = getSc("pl"); if (sc.done) return;
        sc[act] = el.getAttribute("data-opt"); sc.mark = null; save(); render(); break;
      case "check":
        if (T) checkTable(id); else if (id === "ks") checkKs(); else checkPl();
        break;
      case "next": advance(); break;
      case "fig": ui.fig = true; render(); break;
      case "fig-close": ui.fig = false; render(); break;
      case "fig-close-bg": if (ev.target === el) { ui.fig = false; render(); } break;
      case "quit": ui.modal = "quit"; render(); break;
      case "modal-no": ui.modal = null; render(); break;
      case "quit-yes": resetAll(); break;
      case "finish":
        if (!S.downloaded) { ui.modal = "finish"; render(); } else resetAll();
        break;
      case "dl-json": if (reflOk()) { download(fileBase() + ".json", "application/json", exportJson()); render(); } break;
      case "dl-csv": if (reflOk()) { download(fileBase() + "-ringkasan.csv", "text/csv;charset=utf-8", exportSummaryCsv()); render(); } break;
      case "dl-log": if (reflOk()) { download(fileBase() + "-log.csv", "text/csv;charset=utf-8", exportLogCsv()); render(); } break;
    }
  }

  document.addEventListener("click", onClick);
  document.addEventListener("submit", function (ev) { ev.preventDefault(); if (S.stage === "intro") startTask(); });
  document.addEventListener("input", function (ev) {
    var f = ev.target.getAttribute && ev.target.getAttribute("data-f");
    if (!f) return;
    if (f.indexOf("refl") === 0) S.refl[+f.slice(4)] = ev.target.value;
    else S.student[f] = ev.target.value;
    save(); refreshGate();
  });
  document.addEventListener("keydown", function (ev) {
    if (ev.key === "Escape") {
      if (ui.modal) { ui.modal = null; render(); }
      else if (ui.fig) { ui.fig = false; render(); }
    }
  });

  /* seret dan lepas (laptop) */
  document.addEventListener("dragstart", function (ev) {
    var chip = ev.target.closest && ev.target.closest(".chip");
    if (!chip || chip.classList.contains("off")) { return; }
    ev.dataTransfer.setData("text/plain", chip.getAttribute("data-col") + "|" + chip.getAttribute("data-opt"));
    ev.dataTransfer.effectAllowed = "move";
  });
  document.addEventListener("dragover", function (ev) {
    var row = ev.target.closest && ev.target.closest(".sentence-row");
    if (row) { ev.preventDefault(); row.classList.add("dragover"); }
  });
  document.addEventListener("dragleave", function (ev) {
    var row = ev.target.closest && ev.target.closest(".sentence-row");
    if (row) row.classList.remove("dragover");
  });
  document.addEventListener("drop", function (ev) {
    var row = ev.target.closest && ev.target.closest(".sentence-row");
    if (!row) return;
    ev.preventDefault();
    row.classList.remove("dragover");
    var d = (ev.dataTransfer.getData("text/plain") || "").split("|");
    if (d.length < 2) return;
    var i = +d[0], oid = d.slice(1).join("|"), sc = getSc(S.stage);
    if (sc.sel[i] !== oid) pick(i, oid);
  });

  /* ------------------------- mulai ------------------------- */
  if (inProgress()) {
    var r = remainingMs();
    if (r != null && r <= 0) { S.finishedAt = S.finishedAt || Date.now(); S.timedOut = true; S.stage = "hasil"; save(); }
  }
  render();
})();
